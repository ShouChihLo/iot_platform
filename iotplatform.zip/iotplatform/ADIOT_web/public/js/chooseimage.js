function randomimage()
{
        var rannum=Math.round(6*Math.random());
        if(rannum==0)
        document.write("<img src='images/pic01.jpg'>");
        else if(rannum==1)
        document.write("<img src='images/pic02.jpg'>");
        else if(rannum==2)
        document.write("<img src='images/pic03.jpg'>");
        else if(rannum==3)
        document.write("<img src='images/pic04.jpg'>");
        else if(rannum==4)
        document.write("<img src='images/pic05.jpg'>");
        else if(rannum==5)
        document.write("<img src='images/pic06.jpg'>");
}

