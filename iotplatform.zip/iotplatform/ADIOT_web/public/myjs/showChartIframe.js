$(document).ready(function() {



    var feeddata = ["test", 0, 0, 0, 0, 0, 0];
    var feedtime = ['x', '0', '0', '0', '0', '0', '0'];

    var chart = c3.generate({
        bindto: '#chart',
        size: {
            height: 360
        },
        data: {
            x: 'x',
            columns: [
                feedtime,
                feeddata
            ],
            labels: true
        },
        axis: {
            x: {
                type: 'timeseries',
                tick: {
                    format: '%Y-%m-%d %H:%M:%S'
                }
            },
            y: {
                max: 100,
                min: 0
            }
        }
    });



    /*-----------------mqtt part-------------------------------------------*/
    var wsbroker = "mqtt://127.0.0.1"; //mqtt websocket enabled broker
    var wsport = 1883 // port for above
    var client = new Paho.MQTT.Client(wsbroker, wsport,
        "myclientid_" + parseInt(Math.random() * 100, 10));

    client.onConnectionLost = function(responseObject) {
        console.log("----------");
        console.log("connection lost: " + responseObject.errorMessage);
    };
    client.onMessageArrived = function(message) {
        console.log("----------");
        console.log(message.destinationName, ' -- ', message.payloadString, '--', new Date());
        // feeddata.shift();
        console.log(message.destinationName);
        console.log(message.payloadString);
        feeddata.push(parseFloat(message.payloadString));
        feedtime.push(new Date());
        feeddata = [feeddata[0]].concat(feeddata.slice(1).slice(-5));
        feedtime = [feedtime[0]].concat(feedtime.slice(1).slice(-5));
        console.log(feeddata);
        console.log(feedtime);
        chart.load({
            columns: [
                feedtime,
                feeddata
            ]
        });


    };
    var options = {
        timeout: 3,
        onSuccess: function() {
            console.log("mqtt connected");
            // Connection succeeded; subscribe to our topic, you can add multile lines of these
            client.subscribe('<%= topic%>', { qos: 1 });

        },
        onFailure: function(message) {
            console.log("Connection failed: " + message.errorMessage);
        }
    };

    client.connect(options);

});
