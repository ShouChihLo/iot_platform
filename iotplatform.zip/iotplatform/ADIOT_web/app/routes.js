var Space = require('./models/space');
var Sensor = require('./models/sensor');
var Dataspace = require('./models/dataspace');
var Actuator = require('./models/actuator');
var Rule = require('./models/rule');
var Anomaly = require('./models/anomaly');
var FB = require('fb');
var request = require('request');
var sparkConfig = require('../config/sparkConfig');
var jsdom = require('jsdom');
var coap = require('coap');
const http  = require('http');
const mqtt  = require('mqtt');
var Base64 = require('js-base64').Base64;

var path = require('path');
var fs = require("fs");
var redis = require("redis"),
    client = redis.createClient();
var crypto = require('crypto');
module.exports = function(app, passport) {
  console.log("============= routes.js ======================");



  // =====================================
  // HOME PAGE (with login links) ========
  // =====================================
  app.get('/', function(req, res) {

    // if user is authenticated in the session, carry on
    if (req.isAuthenticated()) {
      res.redirect('/mySpaces');
    } else {
      res.render('index.ejs', {
        message: req.flash('loginMessage')
      });
    }

    // if they aren't redirect them to the home page


  });



  // =====================================
  // mySpaces SECTION =====================
  // =====================================
  // Device Management
  app.get('/mySpaces', isLoggedIn, function(req, res) {
    Space.find({
      spaceOwner: req.user.randomEmail
    }, function(err, spaces, count) {
      res.render('mySpaces.ejs', {
        user: req.user, // get the user out of session and pass to template
        spaces: spaces
      });
    });

  });
    
    
  // =====================================
  // myData SECTION =====================
  // =====================================
  // Data Visualization 
  app.get('/myData', isLoggedIn, function(req, res) {
    Dataspace.find({
      Owner: req.user.randomEmail
    }, function(err, dataspaces, count) {
      res.render('myData.ejs', {
        user: req.user, // get the user out of session and pass to template
        dataspaces: dataspaces,
      });
    });
  });
    
    
  // =====================================
  // analysis SECTION =====================
  // =====================================
  // Data Analysis 
  app.get('/analysis', isLoggedIn, function(req, res) {
        Rule.find({
          ruleOwner: req.user.randomEmail
        }, function(err, rules) {
            if (err) {
                    console.log(err);
            } else {
                    Sensor.find({
                        sensorOwner: req.user.randomEmail
                    }, function(err, sensors) {
                            if (err) {
                                console.log(err);
                            } else {
                                    Actuator.find({
                                        actuatorOwner: req.user.randomEmail
                                    }, function(err, actuators) {
                                            if (err) {
                                              console.log(err);
                                            } else {
                                                  res.render('analysis.ejs', {
                                                    user: req.user,
                                                    rules: rules,
                                                    sensors: sensors,
                                                    actuators: actuators
                                                  });
                                              }
                                        });
                             }
                    });
              }
        });
  });
    
// Device Management
// Create a Smart Space to carry out Service Discovery
  app.get('/createSpace', isLoggedIn, function(req, res) {
    console.log(req);
  var buf = crypto.randomBytes(16);
  var Session_Key=Base64.encodeURI(buf.toString('base64'));
    console.log(Session_Key);

    res.render('createSpace.ejs', {
    docs:Session_Key
    });
  });

  app.post('/createNewSpace', isLoggedIn, function(req, res) {

      var gateway_IP=Base64.encodeURI(req.body.ipaddress);
      var Session_Key=req.body.token;
      client.set(gateway_IP+"/Session_Key",Session_Key);
      var newSpace = new Space();

      // set the user's local credentials
      newSpace.spaceOwner = req.user.randomEmail;
      newSpace.spaceName = req.body.newSpace;
      newSpace.spaceLocation = req.body.location;
      newSpace.spaceDescription = req.body.message;
      newSpace.spaceProtocol = req.body.protocol;
      newSpace.spaceIPaddress = req.body.ipaddress;

      // save the user
      newSpace.save(function(err, spacedetail, count) {
        if (err)
          throw err;
        else {
          res.redirect('/spaceDetails/' + req.body.newSpace +'/' + spacedetail._id);
        }
    });
  });

// Data Visualization
// Create a Observed Space to show the instant sensing data chart
// Up to two sensing devices can be selected as the target data
  app.get('/createData', isLoggedIn, function(req, res) {

    var searchStr = req.query.searchStr;
    Sensor.find({
    }, function(err, sensors, docs) {
      var owner = req.user.randomEmail;
      res.render('createData.ejs', {
        sensors: sensors,
        owner:owner,
        searchStr:searchStr
      });
    });
  });
  app.post('/createNewData', isLoggedIn, function(req, res) {
        console.log(req.body.count);
        console.log(req.body.arrayOfCheckedId);
        console.log(req.body.dataSpaceName);
        console.log('============**=============');

        var arrayOfSensorName = [];
        var arrayOfSensorOwner = [];
        var i;
        var newDataspace = new Dataspace();

        for(i=0;i<req.body.count;i++){

            Sensor.findOne({
                sensorsTopicName: req.body.arrayOfCheckedId[i]
            }, function(err, sensors) {
                if (err) {
                    console.log(err);
                } else {
                    arrayOfSensorOwner.push(sensors.sensorOwner);
                    arrayOfSensorName.push(sensors.sensorName);

                    console.log('1**********');
                    console.log(sensors.sensorOwner);
                    console.log('**********');

                    console.log('2**********');
                    console.log(arrayOfSensorName);
                    console.log('**********');
                    console.log(arrayOfSensorOwner);
                    console.log('**********');

                     //set the user's local credentials
                    newDataspace.Owner = req.user.randomEmail;
                    newDataspace.Name = req.body.dataSpaceName;
                    newDataspace.SensorStName = arrayOfSensorName[0];
                    newDataspace.SensorStTopic = req.body.arrayOfCheckedId[0];
                    newDataspace.SensorStOwner = arrayOfSensorOwner[0]
                    newDataspace.SensorNdName = arrayOfSensorName[1];
                    newDataspace.SensorNdTopic = req.body.arrayOfCheckedId[1];
                    newDataspace.SensorNdOwner = arrayOfSensorOwner[1]


                    // save the user
                    newDataspace.save(function(err, dataspacedetail, count) {
                       console.log(dataspacedetail);
                      if (err)
                        //throw err;
                          console.log("err");
                      else {
                        res.redirect('/myData');
                      }
                        res.redirect('/myData');
                    });
                }
            });
        }
  });

// Device Management Detail Page
  app.get('/spaceDetails/:spaceName/:spaceID', isLoggedIn, function(req, res) {
    console.log(req.user);
    // console.log(req.user.randomEmail);
    Sensor.find({
      sensorOwner: req.user.randomEmail,
      spaceOfSensor: req.params.spaceName
    }, function(err, sensors) {
      if (err) {
        console.log(err);
      } else {
        if (req.user.facebook.token) {
          console.log('has fb link');
          FB.api('me', {
            fields: 'friendlists{name}, groups',
            limit: 250,
            access_token: req.user.facebook.token
          }, function(result) {
            if (!result || result.error) {
              console.log(result);
            } else {

              Actuator.find({
                actuatorOwner: req.user.randomEmail,
                actuatorSpace: req.params.spaceName
              }, function(err, actuatorList) {
                if (err) {
                  console.log(err);
                } else {
                  //-------------------------------
                  if (!result || result.error) {
                    return res.send(500, 'error');
                  }

                  var groupsList = null;
                  if (result.groups) {
                    groupsList = result.groups.data;
                  } else {

                  }
                  console.log(actuatorList);

                  //result.friendlists.data.shift();
                  res.render('spaceDetailsPg.ejs', {
                    user: req.user, // get the user out of session and pass to template
                    sensors: sensors,
                    space: req.params.spaceName,
                    spaceID: req.params.spaceID,
                    //fb_friendlists: result.friendlists.data,
                    fb_groups: groupsList,
                    actuatorList: actuatorList
                  });
                  console.log('修改成功'+actuatorList+"++")
                  console.log('修改成功'+sensors+"**")
                  //--------------------------------

                }
              });

            }

          });

        } else {
          console.log('not login fb');
          res.render('spaceDetailsPg.ejs', {
            user: req.user,
            sensors: sensors,
            space: req.params.spaceName,
            spaceID: req.params.spaceID
          });

        }

      }



    });
  });

    
// Data Visalization Detail Page
    app.get('/graphDetails/:spaceName/:spaceID/:topicName1/:topicName2', isLoggedIn, function(req, res) {
    Sensor.find({
        $or: [ { sensorsTopicName: req.params.topicName1 }, { sensorsTopicName: req.params.topicName2 } ]
    }, function(err, sensors) {
      var number=2;
      if (err) {
        console.log(err);
      } else {
          res.render('graphDetailsPg.ejs', {
            user: req.user, // get the user out of session and pass to template
            sensors: sensors,
            space: req.params.spaceName,
            spaceID: req.params.spaceID,
            number:number
          });
      }
    });
  });
    app.get('/graphDetails/:spaceName/:spaceID/:topicName1', isLoggedIn, function(req, res) {
    var topic = req.params.topicName1;
    var sensor =topic.split("/")[2];
    if(sensor!='4002'){
        Sensor.find({sensorsTopicName: req.params.topicName1}, function(err, sensors) {
          var number=1;
          if (err) {
            console.log(err);
          } else {
              res.render('graphDetailsPg.ejs', {
                user: req.user,
                sensors: sensors,
                space: req.params.spaceName,
                spaceID: req.params.spaceID,
                number:number
              });
          }
        });
    }else if(sensor=='4002'){//sensing data is GPS
        Sensor.find({sensorsTopicName: req.params.topicName1}, function(err, sensors) {
          var number=1;
          if (err) {
            console.log(err);
          } else {
              res.render('graphMapPg.ejs', {
                user: req.user,
                sensors: sensors,
                space: req.params.spaceName,
                spaceID: req.params.spaceID,
                number:number
              });
          }
        });
    }
  });
//myData(Data Visualization), It is judged whether or not there is more than two sensing devices selected by the user
    app.post('/enterOrNot', isLoggedIn, function(req, res) {
        console.log(req.body.t1);
        console.log(req.body.t2);

        var T1=req.body.t1,T2=req.body.t2;
        var pubt1,pubt2;
        var user1,user2;
        var judge1,judge2="true";
        var userEmail=req.user.randomEmail;

        if(T1.length>1 && T2.length>1){
            Sensor.findOne({ sensorsTopicName: T1
            }, function(err, sensors) {
            if (err) {
                console.log(err);
            } else {
                pubt1 = sensors.sensorPub;
                user1 = sensors.sensorOwner;
                if((user1!=userEmail) && (pubt1=="false")){
                    judge1="false";
                }else{judge1="true";}
            }
            });

            Sensor.findOne({ sensorsTopicName: T2
            }, function(err, sensors) {
            if (err) {
                console.log(err);
            } else {
                pubt2 = sensors.sensorPub;
                user2 = sensors.sensorOwner;
                if((user2!=userEmail) && (pubt2=="false")){
                    judge2="false";
                }else{judge2="true";}

                if((judge1=="false")||(judge2=="false")){
                    res.json({success: true, s:123});
                }else{res.send("true");}
            }
            });

        }else{
            Sensor.findOne({ sensorsTopicName: T1
            }, function(err, sensors) {
            if (err) {
                console.log(err);
            } else {
                pubt1 = sensors.sensorPub;
                user1 = sensors.sensorOwner;
                if((user1!=userEmail) && (pubt1=="false")){
                    judge1="false";
                }else{judge1="true";}

                if((judge1=="false")||(judge2=="false")){
                    //console.log("2"+judge1+"--"+judge2);
                    //res.send("false");
                    res.json({success: true,s:123});
                }else{res.send("true");}
            }
            });
        }
    });

// To show instant sening data chart
  app.get('/passValueForChart/1/:host/:port/:topic/:UUID/:type', isLoggedIn, function(req, res) {

    Sensor.findOne({
    sensorsTopicName:req.params.topic+'/'+req.params.UUID+'/'+req.params.type}, 'sensorLog sensorName sensorTags', function(err, mylog) {
      if (err) {
        console.log(err);
      } else {
        console.log(mylog);
        console.log('---------------------');
        console.log(req.params.topic);
        console.log(req.params.UUID);
        console.log(req.params.type);
        console.log('--log-----------------');
        var hostname = req.params.host;
        var port = req.params.port;
        var topic = req.params.topic+'/'+req.params.UUID+'/'+req.params.type;
        var number = 1;
        res.render('showChartIframePg.ejs', {
          hostname: hostname,
          port: port,
          topic: topic,
          topic2: topic,
          payloads: mylog,
          payloads3: mylog,
          number:number
        });
      }
    });
  });

    app.get('/passValueForChart/1/:host/:port/:topic/:UUID/:type/:topic2/:UUID2/:type2', isLoggedIn, function(req, res) {

    Sensor.findOne({
    sensorsTopicName:req.params.topic+'/'+req.params.UUID+'/'+req.params.type}, 'sensorLog sensorName sensorTags', function(err, mylog) {
      if (err) {
        console.log(err);
      } else {
        console.log(mylog);
        console.log('---------------------');
        console.log(req.params.topic);
        console.log(req.params.UUID);
        console.log(req.params.type);
        console.log('--log-----------------');
        var hostname = req.params.host;
        var port = req.params.port;
        var topic = req.params.topic+'/'+req.params.UUID+'/'+req.params.type;
        var topic2 = req.params.topic2+'/'+req.params.UUID2+'/'+req.params.type2;
        var number = 2;

        Sensor.findOne({
            sensorsTopicName:req.params.topic2+'/'+req.params.UUID2+'/'+req.params.type2}, 'sensorLog sensorName sensorTags', function(err, mylog2) {

            if (err) {
                console.log(err);
            } else {
                console.log(mylog2);
                res.render('showChartIframePg.ejs', {
                      hostname: hostname,
                      port: port,
                      topic: topic,
                      payloads: mylog,
                      topic2: topic2,
                      payloads3: mylog2,
                      number:number
                });
            }
        });
      }
    });
  });
//Gauge
  app.get('/passValueForChart/2/:host/:port/:topic/:UUID/:type', isLoggedIn, function(req, res) {

    Sensor.findOne({
    sensorsTopicName:req.params.topic+'/'+req.params.UUID+'/'+req.params.type}, 'sensorLog sensorName', function(err, mylog) {
      if (err) {
        console.log(err);
      } else {
        console.log(mylog);
        console.log('---------------------');
        console.log(req.params.topic);
        console.log(req.params.UUID);
        console.log(req.params.type);
        console.log('--log-----------------');
        var hostname = req.params.host;
        var port = req.params.port;
        var topic = req.params.topic+'/'+req.params.UUID+'/'+req.params.type;
        res.render('showGaugeIframePg.ejs', {
          hostname: hostname,
          port: port,
          topic: topic,
          payloads: mylog

        });
      }
    });
  });

//Map
  app.get('/passValueForChart/3/:host/:port/:topic/:UUID/:type', isLoggedIn, function(req, res) {

    Sensor.findOne({
    sensorsTopicName:req.params.topic+'/'+req.params.UUID+'/'+req.params.type}, 'sensorLog sensorName', function(err, mylog) {
      if (err) {
        console.log(err);
      } else {
        console.log(mylog);
        console.log('---------------------');
        console.log(req.params.topic);
        console.log(req.params.UUID);
        console.log(req.params.type);
        console.log('--log-----------------');
        var hostname = req.params.host;
        var port = req.params.port;
        var topic = req.params.topic+'/'+req.params.UUID+'/'+req.params.type;
        res.render('showMapIframePg.ejs', {
          hostname: hostname,
          port: port,
          topic: topic,
          payloads: mylog

        });
      }
    });
  });

    // Get Historic sensing data
     app.post('/getHistory', isLoggedIn, function(req, res) {
        console.log(req.body.dataS);
        console.log('*************');
        console.log(req.body.dateValue);
        console.log('*************');

        var  strtime = req.body.dateValue;
        var  strtopic = req.body.dataS;
        console.log(typeof req.body.dataS == 'string');
        if(typeof req.body.dataS == 'string'){
            console.log('strtopic+strtime = '+strtopic+strtime);
            client.hvals(strtopic+strtime , function(err, object) {//後端跟REDIS撈資料
                //console.log(object);//從REDIS撈出的資料
                console.log(JSON.stringify(object));

                var text = "["+JSON.stringify(object)+"]";
                res.render('showHisChartIframePg.ejs',{docs:text});
            });

        }else{
            var  strtopic1 = req.body.dataS[0];
            var  strtopic2 = req.body.dataS[1];
            var object1;
            var object2;
            console.log('strtopic1+strtime = '+strtopic1+strtime);
            client.hvals(strtopic1+strtime , function(err, object) {
                object1=object;
                console.log('strtopic2+strtime = '+strtopic2+strtime);
                client.hvals(strtopic2+strtime , function(err, object) {
                    object2=object;

                    console.log(object1);
                    console.log(object2);
                    var text1 = "["+JSON.stringify(object1)+"]";
                    var text2 = "["+JSON.stringify(object2)+"]";
                    res.render('show2HisChartIframePg.ejs',{docs1:text1,docs2:text2});

                });
            });
        }

  });

    // Data analysis, create a situational rules
    app.get('/createRule', isLoggedIn, function(req, res) {

    Sensor.find({
       sensorOwner: req.user.randomEmail
    }, function(err, sensors) {
            if (err) {
                console.log(err);
            } else {
                  Actuator.find({
                        actuatorOwner: req.user.randomEmail
                      }, function(err, actuators) {
                        if (err) {
                          console.log(err);
                        } else {
                          res.render('createRule.ejs', {
                            sensors: sensors,
                            actuators: actuators
                          });

                        }
                    });
             }
        });
    });

  app.post('/createNewRule', isLoggedIn, function(req, res) {
//     console.log(req.body);
      var demotopic="demotopic";
     if(req.body.actuator==undefined){
         req.body.actuator=' '+','+' '+','+' '+','+' ';
         var newRule = new Rule();

         newRule.ruleOwner = req.user.randomEmail;
         newRule.sensorContent = req.body.sensor;
         newRule.method = req.body.method;
         newRule.upThreshold = req.body.upThreshold;
         newRule.downThreshold = req.body.downThreshold;
         newRule.windowSize = req.body.windowSize;
         newRule.traningList = req.body.traningList;
         newRule.kNearst = req.body.kNearst;
         newRule.score = req.body.score;
         newRule.sound = req.body.sound;
         newRule.action = req.body.action;
         newRule.actuatorContent = req.body.actuator;
         newRule.message = req.body.message;

         newRule.save(function(err, ruledetail, count) {
             console.log(ruledetail);
             if (err)
                 throw err;
             else {
                 if(req.body.sound==undefined){
                         console.log('=======================');
                         console.log('send to spark1');
                         console.log('=======================');
                         var headers = {
                             'User-Agent':       'Super Agent/0.0.1',
                             'Content-Type':     'application/x-www-form-urlencoded'
                         }

                         // Configure the request
                         // Send an anomaly detection command to SPARK
                            var options = {
                                url: "http://" + "spark_server_ip" + ":server_port" + "/v1/submissions/create",
                                method: 'POST',
                                headers: "Content-Type:application/json;charset=UTF-8",
                                json: {
                                      "action" : "CreateSubmissionRequest",
                                      "appArgs" : [ ruledetail._id,req.body.sensor.split(",")[2],req.user.randomEmail,demotopic,'1',"spark_server_ip","spark_server_ip",req.user.facebook.token,req.user.apptoken,req.body.action,req.body.message,req.body.actuator.split(",")[0],req.body.actuator.split(",")[3],req.body.upThreshold,req.body.downThreshold ],
                                      "appResource" : "file:/home/rong/Desktop/System/demo.jar",
                                      "clientSparkVersion" : "2.1.0",
                                      "environmentVariables" : {
                                        "SPARK_ENV_LOADED" : "1"
                                      },
                                      "mainClass" : "com.spark.fjuted.threshold",
                                      "sparkProperties" : {
                                        "spark.jars" : "file:/home/rong/Desktop/System/demo.jar",
                                        "spark.driver.supervise" : "false",
                                        "spark.app.name" : "Demo",
                                        "spark.eventLog.enabled": "true",
                                        "spark.submit.deployMode" : "client",
                                        "spark.master" : "spark://spark_server_ip:port"
                                      }
                                }
                            }

                        // Start the request
                        request(options, function (error, response, body) {
                            if (!error && response.statusCode == 200) {
                                // Print out the response body
                                console.log(body)
                            }
                        })

                        res.redirect('/analysis');

                    }else{// Send an sounition work to JAVA
                        console.log('=======================');
                        console.log('send to java1');
                        console.log(req.body.sound);
                        const http  = require('http');
                        var path = "/RESTfulWS/rest/UserInfoService/Recognition/"+req.body.sound+","+req.user.randomEmail+","+ruledetail._id;
                        var options = {
                          "host":"spark_server_ip",
                          "port":8080,
                          "path": path,
                          "method":"GET"
                        };

                        callback =function(response){
                        var str='';
                        response.on('data',function(chunk){
                        str += chunk;
                        })
                        response.on('end',function(){
                          console.log(str);
                        })
                        }

                        http.request(options, callback).end();
                        console.log('=======================');
                        res.redirect('/analysis');
                    }
      }
    });
     }else{
            var newRule = new Rule();

            newRule.ruleOwner = req.user.randomEmail;
            newRule.sensorContent = req.body.sensor;
            newRule.method = req.body.method;
            newRule.upThreshold = req.body.upThreshold;
            newRule.downThreshold = req.body.downThreshold;
            newRule.windowSize = req.body.windowSize;
            newRule.traningList = req.body.traningList;
            newRule.kNearst = req.body.kNearst;
            newRule.score = req.body.score;
            newRule.sound = req.body.sound;
            newRule.action = req.body.action;
            newRule.actuatorContent = req.body.actuator;
            newRule.message = req.body.message;

            newRule.save(function(err, ruledetail, count) {
               console.log(ruledetail);
              if (err)
                throw err;
              else {
                  if(req.body.sound==undefined){
                            console.log('=======================');
                            console.log('send to spark2');
                            console.log('=======================');
                            var headers = {
                                'User-Agent':       'Super Agent/0.0.1',
                                'Content-Type':     'application/x-www-form-urlencoded'
                            }
                            // Configure the request
                            var options = {
                                url: "http://" + "spark_server_ip" + ":port" + "/v1/submissions/create",
                                method: 'POST',
                                headers: "Content-Type:application/json;charset=UTF-8",
                                json: {
                                      "action" : "CreateSubmissionRequest",
                                      "appArgs" : [ ruledetail._id,req.body.sensor.split(",")[2],req.user.randomEmail,demotopic,'1',"spark_server_ip","spark_server_ip",req.user.facebook.token,req.user.apptoken,req.body.action,req.body.message,req.body.actuator.split(",")[0],req.body.actuator.split(",")[3],req.body.upThreshold,req.body.downThreshold ],
                                      "appResource" : "file:/home/rong/Desktop/System/demo.jar",
                                      "clientSparkVersion" : "2.1.0",
                                      "environmentVariables" : {
                                        "SPARK_ENV_LOADED" : "1"
                                      },
                                      "mainClass" : "com.spark.fjuted.threshold",
                                      "sparkProperties" : {
                                        "spark.jars" : "file:/home/rong/Desktop/System/demo.jar",
                                        "spark.driver.supervise" : "false",
                                        "spark.app.name" : "Demo",
                                        "spark.eventLog.enabled": "true",
                                        "spark.submit.deployMode" : "client",
                                        "spark.master" : "spark://spark_server_ip:port"
                                      }
                                }
                            }
//

                            // Start the request
                            request(options, function (error, response, body) {
                                if (!error && response.statusCode == 200) {
                                    console.log(body);
                                }
                            })
                            res.redirect('/analysis');

                  }else{
                      console.log('=======================');
                      console.log('send to java2');
                      console.log(req.body.sound);
                      const http  = require('http');
                        var path = "/RESTfulWS/rest/UserInfoService/Recognition/"+req.body.sound+","+req.user.randomEmail+","+ruledetail._id;
                        var options = {
                          "host":"spark_server_ip",
                          "port":8080,
                          "path": path,
                          "method":"GET"
                        };

                        callback =function(response){
                        var str='';
                        response.on('data',function(chunk){
                        str += chunk;
                        })
                        response.on('end',function(){
                          console.log(str);
                        })
                        }

                        http.request(options, callback).end();
                        console.log('=======================');
                        res.redirect('/analysis');
                  }
              }
            });

     }

  });
    app.post('/deleteRule', isLoggedIn, function(req, res) {
        //console.log(req.body.value);

        Rule.remove({
                _id:req.body.value
            }, function(err){
              if(err){
                console.log(err)
              }
              console.log('Delete Finish!');
            });
    });
//AnomalyTable
      app.get('/passValueForAnomalyTable/:host/:port/:topic', isLoggedIn, function(req, res) {
              var top = '/'+req.params.topic;
              var port = req.params.port;
              var hostname = req.params.host;

              console.log(top);
              res.render('showAnomalyTablePg.ejs', {
                  hostname: hostname,
                  port: port,
                  topic: top
                  //payloads: mylog
                });

  });

// User's information Page
  app.get('/profile', isLoggedIn, function(req, res) {
    console.log("req.user");
    res.render('profile.ejs', {
      user: req.user,
      message: req.flash('checkAccount')
    });
  });


  app.post('/postToWall', isLoggedIn, function(req, res) {

    var postMessage = req.body.list_message;
    var lists = Object.keys(req.body);
    lists.pop();
    var csvString = "";

    lists.forEach(function(id, i) {
      if (i === (lists.length - 1)) {
        csvString += id;
      } else {
        csvString += id + ', ';
      }
    });
    console.log(csvString);
    FB.api('me/feed', 'post', {
      access_token: req.user.facebook.token,
      message: postMessage,
      privacy: {
        value: "CUSTOM",
        allow: csvString
      }
    }, function(fbRes) {
      if (!fbRes || fbRes.error) {
        console.log(!fbRes ? 'error occurred' : fbRes.error);
        res.json(fbRes.error.message);
      } else {
        console.log('Post Id: ' + fbRes.id);
        res.json(fbRes.id);
      }
    });
  });


  app.post('/postToGroup', isLoggedIn, function(req, res) {
    var postMessage = req.body.group_message;
    var groups = Object.keys(req.body);
    var group_id = groups[0];
    console.log(group_id);
    console.log(postMessage)
    FB.api(group_id + '/feed', 'post', {
      access_token: req.user.facebook.token,
      message: postMessage
    }, function(fbRes) {
      if (!fbRes || fbRes.error) {
        console.log(!fbRes ? 'error occurred' : fbRes.error);
        res.json(fbRes.error.message);
      } else {
        console.log('Post Id: ' + fbRes.id);
        res.json(fbRes.id);
      }
    });
  });

  app.post('/saveAnomalyFeedback', isLoggedIn, function(req, res) {
    console.log("------------ detection setting (from web UI) ----------------------");
    console.log(req.body);
    console.log("------------------------------------------------");

    /* spark streaming command line arguments */
    var sensorToken = req.body.sensorToken;
    var sensorInterval = req.body.interval;

    if (req.body.actuators) {
      var reactProtocol = req.body.actuators.split('|')[1];
      var reactURL = req.body.actuators.split('|')[2];
    } else {
      var reactProtocol = "";
      var reactURL = "";
    }

    if(typeof req.body.friendLists != "undefined") {
      var fb_friendlists = req.body.friendLists;
      var fbAccessToken = req.body.use_friendlist;
    }else {
      var fb_friendlists = "";
    }

    if(typeof req.body.groupLists != "undefined") {
      var  fb_userGroup = req.body.groupLists;
      var fbAccessToken = req.body.use_group;
    }else {
      var fb_userGroup ="";
    }


    if(typeof req.body.friend_comment != "undefined") {
      var friendlist_msg = req.body.friend_comment;
    }else {
      var friendlist_msg = "";
    }

    if(typeof req.body.group_comment != "undefined") {
      var group_msg = req.body.group_comment;
    }else {
      var group_msg = "";
    }

    var mqttBroker = sparkConfig.mqttBroker;
    var mongoDBURL = sparkConfig.mongoDBURL;
    /*------------------------------------------------*/

    var userStrategy = req.body.userStrategy;

    var appArgs = [sensorToken, sensorInterval, reactProtocol, reactURL, fbAccessToken, fb_friendlists, fb_userGroup, friendlist_msg, group_msg, mqttBroker, mongoDBURL];

    var appResource = null;
    var mainClass = null;

    if (userStrategy === "automatic") {
      appResource = sparkConfig.anomaly_SD_location;
      mainClass = sparkConfig.mainClass_anomaly_SD;
    }

    console.log(appArgs);

    var options = {
      url: "http://" + sparkConfig.spark_master_ip + ':port' + "/v1/submissions/create",
      method: "POST",
      json: {
        "action": "CreateSubmissionRequest",
        "appArgs": appArgs,
        "appResource": appResource,
        "clientSparkVersion": sparkConfig.clientVersion,
        "environmentVariables": {
          "SPARK_ENV_LOADED": "1"
        },
        "mainClass": mainClass,
        "sparkProperties": {
          "spark.jars": appResource,
          "spark.driver.supervise": "false",
          "spark.app.name": "Anomaly_SD",
          "spark.eventLog.enabled": "false",
          "spark.submit.deployMode": "cluster",
          "spark.master": "spark://" + sparkConfig.spark_master_ip + ':7077',
          "spark.driver.memory": sparkConfig.driverMemory,
          "spark.driver.cores": sparkConfig.driverCores,
        }
      }
    };

    request(options, function(error, response, body) {
      if (!error && response.statusCode == 200) {

        Sensor.findOne({
          sensorToken: sensorToken
        }, function(err, update_sensor) {
          if (err) {
            console.log(err);
          } else {
            if (req.body.use_friendlist) {
              update_sensor.sensorReact.facebook.tofriends.lists = req.body.friendLists;
              update_sensor.sensorReact.facebook.tofriends.comment = req.body.friend_comment;
            }
            if (req.body.use_group) {
              update_sensor.sensorReact.facebook.toGroups.lists = req.body.groupLists;
              update_sensor.sensorReact.facebook.toGroups.comment = req.body.group_comment;
            }
            update_sensor.sensorReact.facebook.token = req.body.sensorToken;
            update_sensor.detect = "collecting";
            console.log(body.submissionId);
            console.log(body["submissionId"]);
            console.log(typeof body);
            //console.log(JSON.parse(body));
            update_sensor.submissionID = body.submissionId;
            update_sensor.sensorReact.wot = req.body.actuators;
            update_sensor.save(function(err, doc) {
              if (err) {
                console.log(err);
              } else {
                // res.json("123");
                res.send(body);
              }
            });
          }
        });

        // console.log(body.id) // Print the shortened url.
        // console.log(response);
        // console.log(body);
        // res.json(body);
      } else {
        console.log(error);
        // console.log(response);
      }
    });


  });

   app.post('/killSparkTask', isLoggedIn, function(req, res) {
    request({
      url: "http://" + sparkConfig.spark_master_ip + ':6066' + "/v1/submissions/kill/" + req.body.submitID,
      method: "POST"
    }, function(error, response, body) {
      if (!error && response.statusCode == 200) {

        Sensor.findOne({
          sensorToken: req.body.sensorToken
        }, function(err, update_sensor) {
          if (err) {
            console.log(err);
          } else {
            update_sensor.detect = false;
            update_sensor.save(function(err, doc) {
              if (err) {
                console.log(err);
              } else {
                res.json(body);
              }
            });
          }
        });
      } else {
        console.log(error);
      }
    });
  });


//按下service discovery按鈕後開始執行以下
  app.post('/addNewActuator', isLoggedIn, function(req, res) {
    console.log("============== /addNewActuator =====================");
    Actuator.remove({//刪除目前空間的控制器
        actuatorOwner : req.user.randomEmail,
        actuatorSpace : req.body.spaceName,
    }, function(err){
      if(err){
        console.log(err)
      }
      console.log('刪除成功')
    });
    Sensor.remove({//刪除目前空間的感測器
        sensorOwner : req.user.randomEmail,
        spaceOfSensor : req.body.spaceName,
    }, function(err){
      if(err){
        console.log(err)
      }
      console.log('刪除成功2')
    });

   Space.find({
    spaceOwner : req.user.randomEmail,
    spaceName : req.body.spaceName
   }, function(err, doc) {

      if (err) {
              console.log(err);
            } else {
              var data2=JSON.stringify(doc);
              var str="";
              for(var i=1;i<data2.length-1;i++){
                str+=data2[i];
              }
              var data=JSON.parse(str.toString());
              console.log(data.spaceIPaddress);
              console.log(data.spaceProtocol);
var payloads=JSON.stringify({
    'IP':data.spaceIPaddress,
    'protocol':data.spaceProtocol,
    'actuatorName':req.body.spaceName,
    'actuatorOwner': req.user.randomEmail,
    'actuatorSpace':req.body.spaceName
    });

//依照不同傳輸協定來發送服務發現的請求
      if(data.spaceProtocol!=='mqtt'){
        send_discovery_request(data.spaceIPaddress,payloads);
        console.log('HTTP');
     }else{
        send_mqtt_discovery_request(data.spaceIPaddress,payloads);
        setTimeout(receive_mqtt_discovery_response, 2000,data.spaceIPaddress);

     }


            }
       });


  });

// When User operate sensor public or not button in Device Management Page
    app.post('/changePub', isLoggedIn, function(req, res) {
        Sensor.update({sensorsTopicName:req.body.id},{
                     $set:{
                          sensorPub: req.body.sensorpub
                        }
                      },function (err, count) {
                        if (err) {
                            return console.error(err);
                        }
                        console.log("Data update !");
                    });
    });
// modify sensor's tags in Device Management Page
    app.post('/changeTags', isLoggedIn, function(req, res) {
        Sensor.update({sensorsTopicName:req.body.id},{
                     $set:{
                          sensorTags: req.body.sensortags
                        }
                      },function (err, count) {
                        if (err) {
                            return console.error(err);
                        }
                        console.log("資料已update !");
                    });
    });

   app.post('/saveAnomalyAndWs', outerAuth, function(req, res) { //outerAuth is net yet implemented

    var conditions = {
        sensorToken: req.body.topicName
      },
      update = {
        $push: {
          anomalyRecord: {
            $each: [{
              anomalyData: req.body.anomalyData,
              utcTime: req.body.utcTime,
              topicName: req.body.topicName
            }],
            $sort: {
              date: 1
            },
            $slice: -5
          }
        }
      },
      options = {
        multi: false
      };

    Sensor.update(conditions, update, options, function(err, doc) {
      console.log(doc);
      res.send("ok");

    });
  });

   app.get('/longPollingGetAnomaly/:spaceID', isLoggedIn, function(req, res) {

    Sensor.find({
      "spaceID": req.params.spaceID,
      "anomalyRecord": {
        $exists: true,
        $ne: []
      }
    }, 'sensorName anomalyRecord', function(err, doc) {
      if (err) {
        console.log(err);
      } else {
        console.log("app.get('/longPollingGetAnomaly/:spaceID'");

        if (doc.length === 0) { //no anomaly
          res.json("noAnomaly");
        } else {
          res.json(doc);
        }


      }
    });

  });

  app.get('/sparkClusterStatus/:prevent304string', function(req, res) {
    var localjquery = fs.readFileSync(path.join(__dirname, '../public/js') + '/jquery-1.8.3.min.js', 'utf8');

    jsdom.env({
      url: "http://" + sparkConfig.spark_master_ip + ":8080",
      src: [localjquery],
      done: function(err, window) {
        if (err === null) {
          var $ = window.$;

          var htmlText_Status = $("body div div:nth-child(2) ul li:nth-child(8)").text();
          var clusterStatus = htmlText_Status.split(":")[1].trim();

          var htmlText_memory = $("body div div:nth-child(2) ul li:nth-child(5)").text();
          var totalMemoryMB = htmlText_memory.split(":")[1].trim().split(",")[0].trim().replace(" GB Total", "") * 1024;
          var usedMemoryMB = htmlText_memory.split(":")[1].trim().split(",")[1].trim().split(" ")[0].trim();
          var restMemory = totalMemoryMB * 0.75 - usedMemoryMB;
          var enoughMemory = !(sparkConfig.driverMemory > restMemory)

          var htmlText_cores = $("body div div:nth-child(2) ul li:nth-child(4)").text();
          var totalCores = htmlText_cores.split(":")[1].trim().split(",")[0].trim().replace(" Total", '');
          var usedCores = htmlText_cores.split(":")[1].trim().split(",")[1].trim().replace(" Used", '');
          var restCores = totalCores - usedCores;
          var enoughCores = !(sparkConfig.driverCores > restCores)

          var statusObj = {
            'status': clusterStatus,
            'enoughMemory': enoughMemory,
            'enoughCores': enoughCores
          };

          res.json(statusObj);
        } else {
          var statusObj = {
            'status': "close",
            'enoughMemory': false,
            'enoughCores': false
          };
          console.log(err);
          res.json(statusObj);
        }

      }
    });
  });

//按下ON/OFF控制控制器時執行以下程式
app.post('/actuatorTest', isLoggedIn, function(req, res) {
  console.log(req.body.actuatorUrl);
  console.log(req.body.protocol);
  console.log(req.body.actuatorON_OFF);
      var a=""+req.body.actuatorUrl;
      var ip2="";
      var i=0;
      while(a[i]!=='/'){
        ip2+=a[i];
        i++;
      }
      ip=Base64.decode(ip2);
      if(ip!==""){


 if (req.body.protocol !== "mqtt") {
var ON_OFF="";
if(req.body.actuatorON_OFF==="ON"){
ON_OFF="1";
}else{
ON_OFF="0";
}

  var actuator_data=req.body.actuatorUrl+'/'+ON_OFF;
  sendActuatorhttp(actuator_data,ip,req.body.protocol);
  console.log("actuator_data");
  res.json("Success");

} else {
var ON_OFF="";
if(req.body.actuatorON_OFF==="ON"){
ON_OFF="1";
}else{
ON_OFF="0";
}
  var actuator_data=req.body.actuatorUrl+'/'+ON_OFF;
  console.log(actuator_data);
  sendActuatormqtt(actuator_data,ip);

      res.json("Success");
      }
    }

  });

//按下睡眠控制時執行以下程式
app.post('/Power_Saving', isLoggedIn, function(req, res) {
  console.log(req.body.actuatorUrl);
  console.log(req.body.actuatorON_OFF);

        Sensor.findOne({
          sensorsTopicName:req.body.actuatorUrl
        }, function(err, sensors) {
          if (err) {
            console.log(err);
          } else {
            var Power_protocol=sensors.sensorProtocol;
        var a=""+req.body.actuatorUrl;
      var ip2="";
      var i=0;
      while(a[i]!=='/'){
        ip2+=a[i];
        i++;
      }
      ip=Base64.decode(ip2);
      if(ip!==""){


 if (Power_protocol !== "mqtt") {

  var actuator_data=req.body.actuatorUrl+'/'+req.body.actuatorON_OFF;
  console.log(actuator_data+"**");
  sendActuatorhttp(actuator_data,ip,Power_protocol);
  res.json("Success");

} else {

  var actuator_data=req.body.actuatorUrl+'/'+req.body.actuatorON_OFF;
  console.log(actuator_data);
  sendActuatormqtt(actuator_data,ip);

      res.json("Success");
      }
    }
          }
        });


  });

//將http和CoAP感測閘道器回送的服務資源切割並存入mongoDB
app.put('/discovery_response', function(req, res) {

var str1="";
   req.on('data', function(chunk) {
    str1+=chunk;
    var payload=JSON.parse(str1.toString());//變正常(沒有/)
    //console.log(payload);
    //var discovery_data=JSON.parse(payload.discovery_data);
    //var discovery_data=payload.discovery_data;
    var user_data=JSON.parse(payload.user_data);
    var ip2=Base64.encodeURI(user_data.IP);
var b=payload.discovery_data;
var str="";
var m=0;
for(var j=0;j<b.length-1;j++){

  if(b[j+1]==='{'){
    m=1;
  }else if(b[j]==='}'){
    m=2;
  }
  if(m===1){
  str+=b[j+1];
  }else if(m===2){
    console.log(str)
    var s=JSON.parse(str);//s是切好的
    console.log(s.TYPE)
    str="";
    m=0;
   var a=s.TYPE;
    if(b!=="" && user_data!==""){
          var q="";
          for(var i=0;i<=a.length;i++){
            if(i===a.length){
               //console.log(q+"++++****");

          var q_Name="";
    var n=0;
          while(q[n]!=='_'&& n!==q.length){
              q_Name+=q[n];
              n++;
          }
          var q_Name_size=q_Name.length;

          if(q_Name_size<=3){

search_name(q_Name,function( name ){
          var newActuator = new Actuator();
          newActuator.actuatorName =  name;
          newActuator.actuatorOwner = user_data.actuatorOwner;
          newActuator.actuatorSpace = user_data.actuatorSpace;
          newActuator.actuatorProtocol = user_data.protocol;
          newActuator.actuatorURL = ip2+'/'+s.UUID+'/'+q_Name;//s是切好的
           var status_1=q[q.length-1];
           var status="";
           if(status_1==='1'){
              status="ON";
           }else if(status_1==='0'){
              status="OFF";
           }
          newActuator.actuatorstatus = status;
          newActuator.save(function(err, doc) {
            if (err) {
              console.log(err);
            } else {
              console.log(doc+"存入資料庫"+name);
              //res.json();
            }
          });
         q="";});}else{
search_name(q_Name,function( name ){
 var newSensor = new Sensor();
          newSensor.sensorName =  name;
          newSensor.sensorOwner = user_data.actuatorOwner;
          newSensor.spaceOfSensor = user_data.actuatorSpace;
          newSensor.sensorProtocol = user_data.protocol;
          newSensor.sensorsTopicName = ip2+'/'+s.UUID+'/'+q_Name;//s是切好的
          newSensor.save(function(err, doc) {
            if (err) {
              console.log(err);
            } else {
              console.log(doc+"存入資料庫2"+name);
              //res.json();
            }
          });
             q="";
             });
          }
            }else if(a[i]==','){
              //console.log(q+"++++****");
               var newActuator = new Actuator();
          var q_Name="";
    var n=0;
          while(q[n]!=='_'&& n!==q.length){
              q_Name+=q[n];
              n++;
          }
          var q_Name_size=q_Name.length;

          if(q_Name_size<=3){
            search_name( q_Name,function( name ){
          newActuator.actuatorName =  name;
          newActuator.actuatorOwner = user_data.actuatorOwner;
          newActuator.actuatorSpace = user_data.actuatorSpace;
          newActuator.actuatorProtocol = user_data.protocol;
          newActuator.actuatorURL = ip2+'/'+s.UUID+'/'+q_Name;//s是切好的
           var status_1=q[q.length-1];
           var status="";
           if(status_1==='1'){
              status="ON";
           }else if(status_1==='0'){
              status="OFF";
           }
          newActuator.actuatorstatus = status;
          newActuator.save(function(err, doc) {
            if (err) {
              console.log(err);
            } else {
              console.log(doc+"存入資料庫");
              //res.json();
            }
          });
              q="";});
           }else{
search_name( q_Name,function( name ){
 var newSensor = new Sensor();
          newSensor.sensorName =  name;
          newSensor.sensorOwner = user_data.actuatorOwner;
          newSensor.spaceOfSensor = user_data.actuatorSpace;
          newSensor.sensorProtocol = user_data.protocol;
          newSensor.sensorsTopicName = ip2+'/'+s.UUID+'/'+q_Name;//s是切好的
          newSensor.save(function(err, doc) {
            if (err) {
              console.log(err);
            } else {
              console.log(doc+"存入資料庫2");
              //res.json();
            }
          });
             q="";});
          }
            }else{
               q+=a[i];
            }
          }

    }
  }

}

    });
    req.on('end', function(){

    });
res.json();
 });





};



// route middleware to make sure a user is logged in
function isLoggedIn(req, res, next) {

  // if user is authenticated in the session, carry on
  if (req.isAuthenticated())
    return next();

  // if they aren't redirect them to the home page
  res.redirect('/');
}

function outerAuth(req, res, next) {
  //TODO: implement auth for outer api post
  return next();
}


function send_discovery_request(ip,payloads){
 var ip2=Base64.encodeURI(ip);
var topic=ip2+'/discovery_request';

//var utxTime=dateFormat(new Date(),"isoUtcDateTime");
var options = {
  "host":"127.0.0.1",//ponte IP
  "path":"/resources/"+topic,
  "method":"put",
    "port":3001
    //"setTimeout":5000
};

callback =function(response){
var str=''
response.on('data',function(chunk){
str += chunk
})
response.on('end',function(){
  console.log(str)
})
}

var body=payloads;
http.request(options, callback).end(body);

}


//actuator------------------------------------------
function sendActuatorhttp(payloads,ip,protocol){
   var payload={
        'protocol':protocol,
        'ip':ip,
        'data':payloads
      };

//var utxTime=dateFormat(new Date(),"isoUtcDateTime");
 var ip2=Base64.encodeURI(ip);
var options = {
  "host":"127.0.0.1",//ponte IP
  "path":"/resources/"+ip2+"/Actuator",
  "method":"put",
    "port":3001
    //"setTimeout":5000
};

callback =function(response){
var str=''
response.on('data',function(chunk){
str += chunk
})
response.on('end',function(){
  console.log(str)
})
}

var body=JSON.stringify(payload);
console.log(body);
http.request(options, callback).end(body);

}

function sendActuatormqtt(payloads,ip){
var ip2=Base64.encodeURI(ip);
var topic=ip2+'/Actuator';

var payload={
  'data':payloads

};

var client =mqtt.connect("mqtt://127.0.0.1:1883");//ponte IP
client.publish(topic,JSON.stringify(payload),{
  retain:true
})
console.log(new Date().toISOString());

client.end()
}





//發送MQTT服務發現的請求到MQTT感測閘道器
function send_mqtt_discovery_request(ip,payloads){
var ip2=Base64.encodeURI(ip);
var topic=ip2+'/discovery_request';
var client = mqtt.connect("mqtt://127.0.0.1:1883");//ponte IP
client.publish(topic,payloads,{
  retain:true
})
client.end();
}

//將mqtt感測閘道器回送的服務資源切割並存入mongoDB
function receive_mqtt_discovery_response(ip){//gateway ip
var client = mqtt.connect('mqtt://127.0.0.1:1883');//ponte ip
var ip2=Base64.encodeURI(ip);
var discovery_URL = ip2+'/discovery_response';

client.on('connect', function () {
   client.subscribe(discovery_URL);
});

client.on('message', function (topic, message) {
  // message is Buffer
  var payload=JSON.stringify({
    'will_message':"null"
  });
  if(payload!==message.toString()){
    sendmqtt2(ip,payload);

    console.log(message.toString());//*************************
    var payload_mqtt=JSON.parse(message.toString());//變正常(沒有/)
    //console.log(payload_mqtt);
    console.log(payload_mqtt);

    //var discovery_data=JSON.parse(payload_mqtt.discovery_data);
    var user_data=JSON.parse(payload_mqtt.user_data);
    //var user_data=payload_mqtt.user_data;
    console.log(payload_mqtt.user_data);

var b=payload_mqtt.discovery_data;
var str="";
var m=0;
for(var j=0;j<b.length-1;j++){
  if(b[j+1]==='{'){
    m=1;
  }else if(b[j]==='}'){
    m=2;
  }
  if(m===1){
  str+=b[j+1];
  }else if(m===2){
    console.log(str)
    var s=JSON.parse(str);//s是切好的
    str="";
    m=0;
   var a=s.TYPE;
    if(b!=="" && user_data!==""){
          var q="";
          for(var i=0;i<=a.length;i++){
            if(i===a.length){
               //console.log(q+"++++****");
          var newActuator = new Actuator();
          var q_Name="";
          var n=0;
            while(q[n]!=='_'&& n!==q.length){
              q_Name+=q[n];
              n++;
          }
          var q_Name_size=q_Name.length;
          if(q_Name_size<=3){
       search_name( q_Name,function( name ){
          newActuator.actuatorName =  name;
          newActuator.actuatorOwner = user_data.actuatorOwner;
          newActuator.actuatorSpace = user_data.actuatorSpace;
          newActuator.actuatorProtocol = user_data.protocol;
          newActuator.actuatorURL = ip2+'/'+s.UUID+'/'+q_Name;//s是切好的
            var status_1=q[q.length-1];
           var status="";
           if(status_1==='1'){
              status="ON";
           }else if(status_1==='0'){
              status="OFF";
           }
          newActuator.actuatorstatus = status;
          newActuator.save(function(err, doc) {
            if (err) {
              console.log(err);
            } else {
              console.log(doc+"存入資料庫");
              //res.json();
            }
            });q="";
          });
           }else{
  search_name( q_Name,function( name ){
 var newSensor = new Sensor();
          newSensor.sensorName =  name;
          newSensor.sensorOwner = user_data.actuatorOwner;
          newSensor.spaceOfSensor = user_data.actuatorSpace;
          newSensor.sensorProtocol = user_data.protocol;
          newSensor.sensorsTopicName = ip2+'/'+s.UUID+'/'+q_Name;//s是切好的
          newSensor.save(function(err, doc) {
            if (err) {
              console.log(err);
            } else {
              console.log(doc+"存入資料庫2");
              //res.json();
            }
            q="";
          });});
          }
            }else if(a[i]==','){
              //console.log(q+"++++****");///////////
               var newActuator = new Actuator();
          var q_Name="";
          var n=0;
          while(q[n]!=='_'&& n!==q.length){
              q_Name+=q[n];
              n++;
          }
          var q_Name_size=q_Name.length;
          if(q_Name_size<=3){
        search_name( q_Name,function( name ){
          newActuator.actuatorName = name;
          newActuator.actuatorOwner = user_data.actuatorOwner;
          newActuator.actuatorSpace = user_data.actuatorSpace;
          newActuator.actuatorProtocol = user_data.protocol;
          newActuator.actuatorURL = ip2+'/'+s.UUID+'/'+q_Name;//s是切好的
           var status_1=q[q.length-1];
           var status="";
           if(status_1==='1'){
              status="ON";
           }else if(status_1==='0'){
              status="OFF";
           }
          newActuator.actuatorstatus = status;
          newActuator.save(function(err, doc) {
            if (err) {
              console.log(err);
            } else {
              console.log(doc+"存入資料庫");
              //res.json();
            }
          });
              q="";});
              }else{
search_name( q_Name,function( name ){
 var newSensor = new Sensor();
          newSensor.sensorName =  name;
          newSensor.sensorOwner = user_data.actuatorOwner;
          newSensor.spaceOfSensor = user_data.actuatorSpace;
          newSensor.sensorProtocol = user_data.protocol;
          newSensor.sensorsTopicName = ip2+'/'+s.UUID+'/'+q_Name;//s是切好的
          newSensor.save(function(err, doc) {
            if (err) {
              console.log(err);
            } else {
              console.log(doc+"存入資料庫2");
              //res.json();
            }
          });
             q="";});
          }
            }else{
               q+=a[i];
            }
          }

    }
  }

}
  }

  client.end();
});
}


//sendmqtt2這個方法是為了避免,讓MQTT感測閘道器因斷線從開,會拿到舊的服務發現請求訊息,而發送一次服務資源
//因此當結束一次服務發現流程時,將會發送一筆訊息將請求蓋掉
//以確保每次服務發現的請求都是真的按下按鈕時,才會執行服務發現
function sendmqtt2(ip,payload){
  var ip2=Base64.encodeURI(ip);
var discovery_URL = ip2+'/discovery_request';
var client = mqtt.connect("mqtt://127.0.0.1:1883");//ponte IP

client.publish(discovery_URL,payload,{
  retain:true
})
client.end();
}


//將type解讀為哪種感測器或控制器的方法
function search_name(type,callback){
  console.log('type:'+type+"*-*-*-*-*-*-*-*-*-*");
  var result="";
  switch (type) {
    case '1001':
      result = 'Humidity';
      console.log("Humidity");

        break;
    case '1002':
      result = 'Temperature';
      console.log("Temperature");
      break;
    case '1':
      result = 'Relay';
      console.log("Relay");
      break;
    case '2':
      result = 'LED';
      console.log("LED");
      break;
    case '3':
      result = 'buzzer';
      console.log("buzzer");
      break;
    case '4001':
      result = 'Decibel';
      console.log("Decibel");
      break;
    case '4002':
      result = 'GPS';
      console.log("GPS");
      break;
}

callback(result);
}


