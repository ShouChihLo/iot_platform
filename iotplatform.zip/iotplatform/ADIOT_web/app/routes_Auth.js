var User = require('../app/models/user');

module.exports = function(app, passport) {


  // =============================================================================
  // AUTHENTICATE (FIRST LOGIN) ==================================================
  // =============================================================================

  // locally --------------------------------
  // LOGIN ===============================

  // show the login form
  app.get('/login', function(req, res) {
    res.render('login.ejs', {
      message: req.flash('loginMessage')
    });
  });

  // process the login form
  app.post('/login', passport.authenticate('local-login', {
    successRedirect: '/mySpaces', // redirect to the secure profile section
    failureRedirect: '/', // redirect back to the signup page if there is an error
    failureFlash: true // allow flash messages
  }));

  // SIGNUP =================================
  // show the signup form
  app.get('/signup', function(req, res) {
    res.render('signup.ejs', {
      message: req.flash('signupMessage')
    });
  });

  // process the signup form
  app.post('/signup', passport.authenticate('local-signup', {
    successRedirect: '/mySpaces', // redirect to the secure profile section
    failureRedirect: '/signup', // redirect back to the signup page if there is an error
    failureFlash: true // allow flash messages
  }));

  // facebook -------------------------------

  // send to facebook to do the authentication
  app.get('/auth/facebook', passport.authenticate('facebook', {
    authType: 'rerequest',
    scope: ['email','read_custom_friendlists','publish_actions','user_managed_groups'],
 display:"page"
  }));

  app.get('/auth/facebook/callback', function(req, res, next) {
    console.log("app.get('/auth/facebook/callback', function(req, res, next)");
    passport.authenticate('facebook', function(err, user, info) {
      console.log("passport.authenticate('facebook', function(err, user, info) {");
      console.log(user);
      if (err) {
        return next(err);
      }
      if (!user) {
        console.log("!user");
        return res.redirect('/profile');
      }

      req.logIn(user, function(err) {
        if (err) {
          //有問題
          return res.redirect('/');
        } else if (req.flash('checkAccount').length) {
          //這裡是連結臉書時，發現此臉書已經跟其他本地帳號連結的情況
          console.log("此臉書已經跟其他本地帳號連結過了");
          return res.redirect('/profile');
        } else if (req.flash('linkingSusses').length) {
          //成功將臉書帳號跟本地帳號連結。
          console.log("成功將臉書帳號跟本地帳號連結。");
          return res.redirect('/profile');
        } else if(req.flash('fbloginsuccuss').length){
          //一般登入
          console.log("臉書從首頁登入, 之前登入過");
          return res.redirect('/mySpaces');

        }else if(req.flash('newFBuserFromLogin').length) {
          console.log("臉書從首頁登入, 而且是第一次");
          return res.redirect('/mySpaces');
        }
      });
    })(req, res, next);
  });


  // =============================================================================
  // AUTHORIZE (ALREADY LOGGED IN / CONNECTING OTHER SOCIAL ACCOUNT) =============
  // =============================================================================

  // locally --------------------------------
  app.get('/connect/local', function(req, res) {
    res.render('connect-local.ejs', {
      message: req.flash('loginMessage')
    });
  });

  app.post('/connect/local', passport.authenticate('local-login-link', {
    successRedirect: '/profile', // redirect to the secure profile section
    failureRedirect: '/connect/local', // redirect back to the signup page if there is an error
    failureFlash: true // allow flash messages
  }));

  // facebook -------------------------------

  // send to facebook to do the authentication
  app.get('/connect/facebook', passport.authorize('facebook', {
    scope: ['email','read_custom_friendlists','publish_actions','user_managed_groups']
  }));

  // handle the callback after facebook has authorized the user
  //useless now
  app.get('/connect/facebook/callback',
    passport.authorize('facebook', {
      successRedirect: '/profile',
      failureRedirect: '/profile'
    }));

	// App Token -----------------------------------------------------------------
	app.post('/apptoken', function(req, res){
		console.log(req.body)
		User.update({'local.email': req.body.user}, {'$set': {'apptoken': req.body.token}},
					function(err, raw){
						if(err){
							console.log('Error log: ' + err);
						}
						else{
							console.log('Token updated: ' + raw);
						}
					}
		);
		res.redirect('/');
	});
  // =============================================================================
  // UNLINK ACCOUNTS =============================================================
  // =============================================================================
  // used to unlink accounts. for social accounts, just remove the token
  // for local account, remove email and password
  // user account will stay active in case they want to reconnect in the future

  // local -----------------------------------
  app.get('/unlink/local', function(req, res) {
    console.log("here is unlink--------");

    var user = req.user;

    var newUser = new User();
    newUser.local.email = user.local.email;
    newUser.local.password = user.local.password;
    newUser.randomEmail = user.local.email;

    user.local.email = undefined;
    user.local.password = undefined;

    user.save(function(err) {
      newUser.save(function(err) {
        if (err) {
          throw err;
        } else {
          // return done(null, newUser);
          res.redirect('/profile');
        }
      });
    });
  });

  // facebook -------------------------------
  app.get('/unlink/facebook', function(req, res) {
    var user = req.user;

    var newUser = new User();
    newUser.facebook.email = user.facebook.email;
    newUser.facebook.name = user.facebook.name;
    newUser.facebook.id = user.facebook.id;
    newUser.facebook.token = user.facebook.token;
    newUser.randomEmail = user.facebook.email;
    newUser.facebook.userGrantedString = user.facebook.userGrantedString;

    user.facebook = undefined;

    user.save(function(err) {

      newUser.save(function(err) {
        if (err) {
          throw err;
        } else {
          // return done(null, newUser);
          res.redirect('/profile');
        }
      });
    });
  });


  // =====================================
  // LOGOUT ==============================
  // =====================================
  app.get('/logout', function(req, res) {
    req.logout();
    res.redirect('/');
  });



};