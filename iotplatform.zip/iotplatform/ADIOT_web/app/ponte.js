var ponte = require("ponte");
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
//var Sensor = require('./models/sensor');
const coap  = require('coap');
var http = require('http');
const mqtt  = require('mqtt')
//mongoose.connect('mongodb://localhost/sensors');
var Base64 = require('js-base64').Base64;

var redis = require("redis");
var redisClient = redis.createClient();

var opts = {
  logger: {
    level: 'info'
  },
  http: {
    port: 3001,
    authenticate: function(req, callback) {
        var auth = req.headers['authorization'];
        callback(null, true,  { username: 'someone' });
      },
      authorizeGet: function(subject, topic, callback) {
        console.log("http -- authorizeGet");
        console.log(subject);
        console.log(topic);
        callback(null, true);
      },
    authorizePut: function(subject, topic, payload, callback) {
      var Access_control_topic="";
      var j=0;
      while(topic[j]!=="/"){
            Access_control_topic+=topic[j];
            j++;
      }

      var topic2="";
      var topic3="";
      var i=topic.length;
      while(topic[i-1]!=="/"){
      topic2+=topic[i-1];
      i--;
      }
      for(var i=topic2.length-1;i>=0;i--){
        topic3+=topic2[i];
      }

  if(topic3==="Authentication"){//如果為驗證訊息
          send_Authentication(topic,payload);//送RA驗證
  }else{
  Access_control(Access_control_topic,function(blacktopic){//存取控制
    console.log(topic3+"=============================================");
    if(blacktopic==="illegal"){
      console.log("黑名單中GG~~~~~~~~~~~~~~~~~~~");
    }else{
      console.log("合法OK~~~~~~~~~~~~~~~~~~~~~~~~~");
      var payloadJSON = JSON.parse(payload);

      //discovery forword------------------------------------------------
      if(topic===Base64.encodeURI(payloadJSON.IP)+"/discovery_request"){
        if(payloadJSON.protocol==='coap'){
          console.log(payloadJSON.protocol);
            coapforward(payload);
        }else if(payloadJSON.protocol==='http'){
           console.log(payloadJSON.protocol);
            httpforward(payload);
        }

      //Actuator forward------------------------------------------------
      }else if(topic===Base64.encodeURI(payloadJSON.ip)+"/Actuator"){
          console.log(payloadJSON);
        if(payloadJSON.protocol==='coap'){
          console.log(payloadJSON.protocol);
          actuatorcoap(payload,payloadJSON.ip);
        }else if(payloadJSON.protocol==='http'){
          console.log(payloadJSON.protocol);
          actuatorhttp(payload,payloadJSON.ip);
        }
      }else{
        if(topic3!=="discovery_request"&&topic3!=="discovery_response"&&topic3!=="Actuator"){
          var payloadJSON = JSON.parse(payload.toString());
          console.log(payloadJSON.data, payloadJSON.utcTime);
          var str="";
          for(var i=0;i<=9;i++){
          str+=payloadJSON.utcTime[i];//拿出時間樣放在key上
          }

          redisClient.hset(topic+str,payloadJSON.utcTime,payload);//感測數據存入redis
          redisClient.hvals(topic+str , function(err, object) {
          console.log(object);//顯示存入redis的感測數據
          });

          console.log("=============================================");
          console.log(topic);
          console.log("=============================================");
        }
      }

    callback(null, true);
    }

  });//存取控制
  }


}

},//HTTP



  mqtt: {
    port: 1883, // tcp
    authenticate: function(client, username, password, callback) {

      callback(null, true);
    },
    authorizePublish: function(client, topic, payload, callback) {
      var Access_control_topic="";
      var j=0;
      while(topic[j]!=="/"){
            Access_control_topic+=topic[j];
            j++;
      }
      //這是用來分析topic最後面是甚麼來判斷是甚麼訊息ex:/Authentication,/Actuator
      var topic2="";
      var topic3="";
      var i=topic.length;
      while(topic[i-1]!=="/"){
      topic2+=topic[i-1];
      i--;
      }
      for(var i=topic2.length-1;i>=0;i--){
        topic3+=topic2[i];
      }
      console.log(topic3+"=============================================");
      if(topic3==="Authentication"){//如果為驗證訊息
        send_Authentication(topic,payload);//送RA驗證
      }else{
  Access_control(Access_control_topic,function(blacktopic){//存取控制
  if(blacktopic==="illegal"){
  console.log("黑名單中GG~~~~~~~~~~~~~~~~~~~");
  }else{
    console.log("合法OK~~~~~~~~~~~~~~~~~~~~~~~~~");
    if(topic3==="spark"){//智慧連動控制
        console.log(payload);
        console.log(payload.toString());
        var Sparkpayload = JSON.parse(payload.toString());
        console.log(Sparkpayload.topicname);
        console.log(Sparkpayload.protocol);
        var str=Sparkpayload.topicname;
        var i=0;
        var IP2="";
        while(str[i]!=="/"){
        IP2+=str[i];
        i++;
        }
        var IP=Base64.decode(IP2);

      ////(智慧連動控制)智慧連動控制
          if(Sparkpayload.protocol==="coap"){
            Sparkactuatorcoap(Sparkpayload.topicname,IP);
        console.log(Sparkpayload.protocol);
          }else if(Sparkpayload.protocol==="http"){
            Sparkactuatorhttp(Sparkpayload.topicname,IP);
        console.log(Sparkpayload.protocol);
          }else if(Sparkpayload.protocol==="mqtt"){
            Sparkactuatormqtt(Sparkpayload.topicname,IP);
        console.log(Sparkpayload.protocol);
          }

        console.log(payload);
        console.log(Sparkpayload);

    }else if(topic3!=="spark"&&topic3!=="discovery_request"&&topic3!=="discovery_response"&&topic3!=="Actuator"){//這是用來分析topic最後面是甚麼來判斷是甚麼訊息ex:/Authentication,/Actuator
      var payloadJSON = JSON.parse(payload.toString());
      console.log(payloadJSON.data, payloadJSON.utcTime);
      var str="";
      for(var i=0;i<=9;i++){
        str+=payloadJSON.utcTime[i];//拿出時間樣放在key上
      }
      redisClient.hset(topic+str,payloadJSON.utcTime,payload);//感測數據存入redis
      redisClient.hvals(topic+str , function(err, object) {
      console.log(object);//顯示存入redis的感測數據
      });
        console.log("=============================================");
        console.log(topic);
        console.log("=============================================");
    }
      callback(null, true);
  }
});//存取控制
}

}

  },//MQTT


  coap: {
    port: 5683, // udp
    authenticate: function(req, callback) {
      callback(null, true, { username: 'someone' });
    },
    authorizePut: function(subject, topic, payload, callback) {
    var Access_control_topic="";
    var j=0;
    while(topic[j]!=="/"){
          Access_control_topic+=topic[j];
          j++;
    }
    console.log(topic);
//這是用來分析topic最後面是甚麼來判斷是甚麼訊息ex:/Authentication,/Actuator
      var topic2="";
      var topic3="";
      var i=topic.length;
      while(topic[i-1]!=="/"){
      topic2+=topic[i-1];
      i--;
      }
      for(var i=topic2.length-1;i>=0;i--){
        topic3+=topic2[i];
      }
if(topic3==="Authentication"){//////如果為驗證訊息
    send_Authentication(topic,payload);//送RA驗證
}else{
Access_control(Access_control_topic,function(blacktopic){//存取控制

      console.log(topic3+"=============================================");
       if(blacktopic==="illegal"){
         console.log("黑名單中GG~~~~~~~~~~~~~~~~~~~");
        }else{
         console.log("合法OK~~~~~~~~~~~~~~~~~~~~~~~~~");
              if(topic3!=="discovery_request"&&topic3!=="discovery_response"&&topic3!=="Actuator"){//如果不為服務發現和控制訊息,則認為是感測數據訊息,要存入資料庫
              var payloadJSON = JSON.parse(payload.toString());
              console.log(payloadJSON.data, payloadJSON.utcTime);
              var str="";
              for(var i=0;i<=9;i++){
                str+=payloadJSON.utcTime[i];//拿出時間樣放在key上
              }

              redisClient.hset(topic+str,payloadJSON.utcTime,payload);//感測數據存入redis
              redisClient.hvals(topic+str , function(err, object) {
              console.log(object);//顯示存入redis的感測數據
              });

              console.log("=============================================");
              console.log(topic);
              console.log("=============================================");

              }
        }
  });//存取控制
}
}

  }//CoAP




};
var server = ponte(opts);

server.on("updated", function(resource, buffer) {
  console.log("Resource Updated", resource, buffer);
});


//轉送服務發現請求到CoAP設備
function coapforward(payload){
var payloadJSON = JSON.parse(payload.toString());
var ip=payloadJSON.IP;
var ip2=Base64.encodeURI(ip);
req = coap.request('coap://'+ip+'/'+ip2+'/discovery_request')
req.on('response', function(res) {
var str='';
str+=res.payload;
  //console.log(str);
  send_discovery_response(str,payload);
})
req.end()
}

//轉送服務發現請求到http設備
function httpforward(payload){
var payloadJSON = JSON.parse(payload.toString());
var ip=payloadJSON.IP;
var ip2=Base64.encodeURI(ip);
 var options = {
     host: ip,
     port: 3001,
     path: '/'+ip2+'/discovery_request',
     method: 'GET'
};
var str='';
http.get(options, function(res) {
  //console.log("Got response: " + res.statusCode);

  res.on("data", function(chunk) {
    str+=chunk;
    console.log(str);
    send_discovery_response(str,payload);
  });
})
}


//將gateway回傳的discovery訊息再送回web---------------------
function send_discovery_response(payload,payloadJSON){

var options = {
  "host":"127.0.0.1",//web位置
  "path":"/discovery_response",////web所開的URL
  "method":"put",
  "port":"8080"
};

callback =function(response){
var str=''
response.on('data',function(chunk){
str += chunk
})
response.on('end',function(){
  //console.log(str)
})
}
var a=""+payloadJSON;
var s={
"discovery_data":payload,
"user_data":a
}

var body=JSON.stringify(s);

console.log(body+"****discovery_response****");
http.request(options, callback).end(body);
}



//actuator forward-----------------------------CoAP
function actuatorcoap(payloads,ip){
var payload2=JSON.parse(payloads.toString());
 var payload=payload2.data;
 var ip2=Base64.encodeURI(ip);

      var req = coap.request({
        host:ip,//ip
        port:5683,
        method:'put',
        pathname:'/'+ip2+'/Actuator'
      });
   console.log(payload.data);

    req.write(JSON.stringify(payload));
     req.on('response', function(res) {
      res.pipe(process.stdout);
      req.on('end', function() {
      res.pipe('end');
        });

      });
      req.end();
}

//actuator forward-----------------------------HTTP
function actuatorhttp(payloads,ip){
var payload2=JSON.parse(payloads.toString());
 var payload=payload2.data;
 var ip2=Base64.encodeURI(ip);
//var utxTime=dateFormat(new Date(),"isoUtcDateTime");
var options = {
  "host":ip,//"192.168.1.140",
  "path":'/'+ip2+'/Actuator',
  "method":"put",
    "port":3001
    //"setTimeout":5000
};

callback =function(response){
var str=''
response.on('data',function(chunk){
str += chunk
})
response.on('end',function(){

})
}

var body=JSON.stringify(payload)
console.log('/'+ip2+'/Actuator'+"******123");
http.request(options, callback).end(body);

}


//將sensor gateway上傳憑證訊息轉送到RA
function send_Authentication(topic,payload){
var topic2="";
var i=0;
while(topic[i]!=="/"){
      topic2+=topic[i];
      i++;
}
var options = {
  "host":"127.0.0.1",//RA位址
  "path":"/Authentication",
  "method":"put",
  "port":"3002"
};

callback =function(response){
var str=''
response.on('data',function(chunk){
str += chunk
})
response.on('end',function(){
  //console.log(str)
})
}
var a=JSON.parse(payload);
var s={
"topic":topic2,
"plaintext":a.plaintext,
"ciphertext":a.ciphertext
}
var body=JSON.stringify(s);
//console.log(body+"668866886688");


console.log(body+"****Authentication****");
http.request(options, callback).end(body);
}

function Access_control(Access_control_topic,callback){
   var blacktopic="";
  redisClient.get(Access_control_topic+"/blacklist", function(err, reply) {
    // reply is null when the key is missing
    var blacktopic=""+reply;
    console.log(blacktopic+"=============================================*******");
  callback(blacktopic);
  });

}



//Spark actuator forward-----------------------------對CoAP設備智慧連動
function Sparkactuatorcoap(payloads,ip){
 var payload=payloads+"/2";
 var ip2=Base64.encodeURI(ip);

      var req = coap.request({
        host:ip,//ip
        port:5683,
        method:'put',
        pathname:'/'+ip2+'/Actuator'
      });
   console.log(payload.data);

    req.write(JSON.stringify(payload));
     req.on('response', function(res) {
      res.pipe(process.stdout);
      req.on('end', function() {
      res.pipe('end');
        });

      });
      req.end();
}


//Spark actuator forward---------------------------對HTTP設備智慧連動
function Sparkactuatorhttp(payloads,ip){

 var payload=payloads+"/2";
 var ip2=Base64.encodeURI(ip);
//var utxTime=dateFormat(new Date(),"isoUtcDateTime");
var options = {
  "host":ip,//"192.168.1.140",
  "path":'/'+ip2+'/Actuator',
  "method":"put",
    "port":3001
    //"setTimeout":5000
};

callback =function(response){
var str=''
response.on('data',function(chunk){
str += chunk
})
response.on('end',function(){

})
}

var body=JSON.stringify(payload)
console.log('/'+ip2+'/Actuator'+"******123");
http.request(options, callback).end(body);

}

//Spark actuator forward---------------------------對MQTT設備智慧連動
function Sparkactuatormqtt(payloads,ip){
var ip2=Base64.encodeURI(ip);
var mqtttopic=ip2+"/Actuator";
var payload=payloads+"/2 ";

var body=JSON.stringify(payload);
var client234 =mqtt.connect("mqtt://127.0.0.1:1883");
client234.publish(mqtttopic,body,{
  retain:true
})

client234.end()
}