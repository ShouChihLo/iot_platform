var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');


// define the schema for our user model
var userSchema = mongoose.Schema({
  sensorsTopicName: String,///sensorOwner: req.user.randomEmail,
                            //spaceOfSensor: req.params.spaceName
  sensorPub:{type: String, default: false},
  sensorTags: String,
  sensorOwner: String,
  spaceOfSensor: String,
  sensorName: String,
  spaceID: String,
  sensorToken: String,
  sensorLog: [{
    payload: String,
    date: Date
  }],
  anomalyRecord: [{
    topicName: String,
    anomalyData: String,
    utcTime: Date,
    mean: String,
    std: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  sensorReact: {
    facebook: {
      tofriends: {
        lists: [String],
        comment: String
      },
      toGroups: {
        lists: [String],
        comment: String
      },
      token: String
    },
    wot: [String]
  },
  detect: {type: String, default: false},
  submissionID: String,
  interval: String,
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

userSchema.methods.generateHash = function(sensorToken) {
  return bcrypt.hashSync(sensorToken, bcrypt.genSaltSync(8), null);
};

// checking if password is valid
userSchema.methods.validPassword = function(sensorToken) {
  return bcrypt.compareSync(sensorToken, this.local.sensorToken);
};

// create the model for users and expose it to our app
module.exports = mongoose.model('Pubsensor', userSchema);