var mongoose = require('mongoose');

// define the schema for our user model
var actuatorSchema = mongoose.Schema({
    actuatorName: String,
    actuatorOwner: String,
    actuatorSpace: String,
    actuatorProtocol: String,
    actuatorURL: String,
    actuatorstatus: String,
    createdAt: {type: Date, default: Date.now},
    updatedAt: {type: Date, default: Date.now}
});

// create the model for users and expose it to our app
module.exports = mongoose.model('Actuator', actuatorSchema);