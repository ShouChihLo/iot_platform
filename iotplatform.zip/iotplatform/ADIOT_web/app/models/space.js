var mongoose = require('mongoose');

// define the schema for our user model
var userSchema = mongoose.Schema({

    spaceOwner: String,
    spaceName: String,
    spaceLocation: String,
    spaceDescription: String,
    spaceProtocol: String,
    spaceIPaddress: String,
    createdAt: {type: Date, default: Date.now},
    updatedAt: {type: Date, default: Date.now}
});



// create the model for users and expose it to our app
module.exports = mongoose.model('Space', userSchema);