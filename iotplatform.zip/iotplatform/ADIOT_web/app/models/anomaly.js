var mongoose = require('mongoose');

// define the schema for our user model
var anomalySchema = mongoose.Schema({
    status: String,
    value: String,
    time: String,
    createdAt: {type: Date, default: Date.now}
});

// create the model for users and expose it to our app
module.exports = mongoose.model('Anomaly', anomalySchema);