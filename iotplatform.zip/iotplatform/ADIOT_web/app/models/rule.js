var mongoose = require('mongoose');

// define the schema for our user model
var ruleSchema = mongoose.Schema({
    ruleOwner: String,
    sensorContent: String,
    method: String,
    upThreshold: String,
    downThreshold: String,
    windowSize: String,
    traningList: String,
    kNearst: String,
    score:String,
    sound:String,
    action: String,
    actuatorContent: String,
    message: String,
    createdAt: {type: Date, default: Date.now}
});

// create the model for users and expose it to our app
module.exports = mongoose.model('Rule', ruleSchema);