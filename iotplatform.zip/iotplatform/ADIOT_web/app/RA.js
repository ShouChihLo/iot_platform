var CryptoJS = require("crypto-js");
var crypto = require('crypto');
var Base64 = require('js-base64').Base64;
var redis = require("redis");
var client = redis.createClient();
var server,
    ip   = "127.0.0.1",//RA自己的IP
    port = 3002,
    url = require('url'),
    path;
const http  = require('http');

server = http.createServer(function (req, res) {
      path = url.parse(req.url);

    res.writeHead(200, {'Content-Type': 'text/plain'});

    switch (path.pathname) {

    case "/Authentication":
        var bodydata = '';
        req.on('data', function (data) {
            bodydata += data;
        });

        req.on('end', function () {
             console.log(bodydata);//送過來的憑證訊息
             var a=JSON.parse(bodydata.toString());
             console.log(a.topic);/////憑證訊息的屬性內容
             console.log(a.plaintext);/////憑證訊息的屬性內容
             console.log(a.ciphertext);/////憑證訊息的屬性內容
             Authentication(a.topic,a.ciphertext,a.plaintext)//進行憑證訊息驗證
           res.end('OK');
        });
        break;
    default:
        res.end('OK');
        break;
    }
    res.end()
});
server.listen(port, function() {
console.log("Server running at http://" + ip + ":" + port);

});

function Authentication(topic,ciphertext,plaintext){
console.log(topic);
 //與資料庫認證
client.get(topic+"/Session_Key", function(err, reply) {//查詢Session Key資料庫中的Session Key
    var web_Session_Key=""+reply;
     if(web_Session_Key==="null"){
          console.log("無Session Key");
    }else{
            // Decrypt//解密
            var bytes  = CryptoJS.AES.decrypt(ciphertext, web_Session_Key);//RA用Session Key資料庫的Session Key進行AES解密
            var pp=bytes+"";//轉字串
            if(pp===""){
                console.log("加入黑名單")
                client.set(topic+"/blacklist", "illegal");//加入黑名單
            }else if(pp.length===64){
           var plaintextRA = bytes.toString(CryptoJS.enc.Utf8);
            console.log("解密:"+plaintextRA);//RA用Session Key資料庫的Session Key進行AES解密的明文
            console.log("公鑰:"+plaintext);//憑證訊息
              if(plaintextRA===plaintext){
                  client.del(topic+"/blacklist");
                  console.log("移除黑名單");
              }else{
                  console.log("加入黑名單")
                  client.set(topic+"/blacklist", "illegal");//加入黑名單
              }


            }else{
                  console.log("加入黑名單")
                  client.set(topic+"/blacklist", "illegal");//加入黑名單
            }
      }

});

}


