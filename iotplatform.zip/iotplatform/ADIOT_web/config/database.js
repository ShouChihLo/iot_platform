module.exports = {
   'url' : 'mongodb://localhost/sensors'
};