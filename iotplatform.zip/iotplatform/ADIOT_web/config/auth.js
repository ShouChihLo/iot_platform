module.exports = {

    'facebookAuth': {
       'clientID'      : '????', //your App ID        : 'your-secret-clientID-here'
       'clientSecret'  : '????', //your App Secret        : 'your-client-secret-here'
      'callbackURL': 'http://localhost:8080/auth/facebook/callback'
    }

};