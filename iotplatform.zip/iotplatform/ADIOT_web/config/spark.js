module.exports = {
    'spark_master_ip': 'your_server_ip',
    'anomaly_SD_location': '',
    'clientVersion' : '2.1.0',
    'mainClass_anomaly_SD': 'Anomaly_SD',
    'driverMemory': '512m',
    'driverCores': '2',
    'mqttBroker': '',
    'mongoDBURL': ''
};