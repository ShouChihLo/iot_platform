module.exports = {
    'spark_master_ip': '192.168.1.116',
    'anomaly_SD_location': 'C:/Users/NANOCO/spark-streaming-anomaly-detection.jar',
    'clientVersion' : '1.6.1',
    'mainClass_anomaly_SD': 'Anomaly_SD',
    'driverMemory': '512m',
    'driverCores': '2',
    'mqttBroker': 'mqtt://192.168.1.140:1883',
    'mongoDBURL': 'mongodb://192.168.1.140:27017/sensors'
};