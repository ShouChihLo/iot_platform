var LocalStrategy = require('passport-local').Strategy;
var FacebookStrategy = require('passport-facebook').Strategy;
var User = require('../app/models/user');
var configAuth = require('./auth');
var request = require('request');

// expose this function to our app using module.exports
module.exports = function(passport) {

  // =========================================================================
  // passport session setup ==================================================
  // =========================================================================
  // required for persistent login sessions
  // passport needs ability to serialize and unserialize users out of session

  // used to serialize the user for the session
  passport.serializeUser(function(user, done) {
    done(null, user.id);
  });

  // used to deserialize the user
  passport.deserializeUser(function(id, done) {
    User.findById(id, function(err, user) {
      done(err, user);
    });
  });

  // =========================================================================
  // LOCAL SIGNUP ============================================================
  // =========================================================================

  passport.use('local-signup', new LocalStrategy({
      // by default, local strategy uses username and password, we will override with email
      usernameField: 'email',
      passwordField: 'password',
      passReqToCallback: true // allows us to pass in the req from our route (lets us check if a user is logged in or not)
    },
    function(req, email, password, done) {

      // asynchronous
      process.nextTick(function() {

        //  Whether we're signing up or connecting an account, we'll need
        //  to know if the email address is in use.
        User.findOne({
          'local.email': email
        }, function(err, existingUser) {

          // if there are any errors, return the error
          if (err)
            return done(err);

          // check to see if there's already a user with that email
          if (existingUser)
            return done(null, false, req.flash('signupMessage', 'That email is already taken.'));

          //  If we're logged in, we're connecting a new local account.
          if (req.user) {
            console.log("=======we're logged in=====================");
            var user = req.user;
            user.local.email = email;
            user.local.password = user.generateHash(password);
            user.save(function(err) {
              if (err)
                throw err;
              return done(null, user);
            });
          }
          //  We're not logged in, so we're creating a brand new user.
          else {
            // create the user
            console.log("=======we're not logged in=====================");

            var newUser = new User();

            newUser.local.email = email;
            newUser.local.password = newUser.generateHash(password);
            newUser.randomEmail = email;
            newUser.apptoken = ' ';

            newUser.save(function(err) {
              if (err)
                throw err;

              return done(null, newUser);
            });
          }

        });
      });

    }));

  // =========================================================================
  // LOCAL LOGIN =============================================================
  // =========================================================================

  passport.use('local-login', new LocalStrategy({
      // by default, local strategy uses username and password, we will override with email
      usernameField: 'email',
      passwordField: 'password',
      passReqToCallback: true // allows us to pass in the req from our route (lets us check if a user is logged in or not)
    },
    function(req, email, password, done) {

      // asynchronous
      process.nextTick(function() {
        User.findOne({
          'local.email': email
        }, function(err, user) {
          // if there are any errors, return the error
          if (err) {
            return done(err);
          }

          // if no user is found, return the message
          if (!user)
            return done(null, false, req.flash('loginMessage', 'No user found.'));

          if (!user.validPassword(password))
            return done(null, false, req.flash('loginMessage', 'Oops! Wrong password.'));

          // all is well, return user
          else
            return done(null, user);
        });
      });

    }));

  // =========================================================================
  // LOCAL LOGIN for link localaccount =============================================================
  // =========================================================================
  passport.use('local-login-link', new LocalStrategy({
      // by default, local strategy uses username and password, we will override with email
      usernameField: 'email',
      passwordField: 'password',
      passReqToCallback: true // allows us to pass in the req from our route (lets us check if a user is logged in or not)
    },
    function(req, email, password, done) {
      // asynchronous
      process.nextTick(function() {
        User.findOne({
          'local.email': email
        }, function(err, user) {
          console.log(user)
          // if there are any errors, return the error
          if (err) {
            return done(err);
          }

          // if no user is found, return the message
          if (!user) {
            return done(null, false, req.flash('loginMessage', 'No user found.'));
          }

          if (!user.validPassword(password)) {
            return done(null, false, req.flash('loginMessage', 'Oops! Wrong password.'));
          }

          if (user.facebook.id) {
            console.log(user.facebook.id);
            return done(null, false, req.flash('loginMessage', '這個本地帳號已經跟別的臉書帳號連結過囉！'));
          }
          // all is well, return user
          if (req.user) {


            User.remove({
              _id: user._id
            }, function(err) {
              if (!err) {
                console.log("成功刪除原本的local account");
                console.log("hash:" + password);
                var user = req.user;
                user.local.email = email;
                user.local.password = user.generateHash(password);
                user.save(function(err) {
                  if (err) {
                    throw err;
                  } else {
                    console.log("已將local account連結至此臉書帳號。");
                    return done(null, user);
                  }
                });
              } else {
                console.log("deleted failed!");

              }
            });


          }
        });
      });

    }));

  // =========================================================================
  // FACEBOOK ================================================================
  // =========================================================================

  passport.use(new FacebookStrategy({

      clientID: configAuth.facebookAuth.clientID,
      clientSecret: configAuth.facebookAuth.clientSecret,
      callbackURL: configAuth.facebookAuth.callbackURL,
      profileFields: ["emails", "displayName", "permissions"],
      passReqToCallback: true // allows us to pass in the req from our route (lets us check if a user is logged in or not)

    },
    function(req, token, refreshToken, profile, done) {

      console.log("====== Use FB Strategy ==============");
      // asynchronous
      process.nextTick(function() {
        console.log("req.user: ==============");

        console.log(JSON.parse(profile._raw).permissions);

        var parsePermissionsString = JSON.parse(profile._raw).permissions;
        var stringifyPermissionsForDb = JSON.stringify(parsePermissionsString);

        console.log("====================");


        // check if the user is already logged in
        if (!req.user) {
          console.log("====  使用者目前沒登入======");

          User.findOne({
            'facebook.id': profile.id
          }, function(err, user) {

            console.log("資料庫讀取完畢。");
            if (err) {
              console.log("有錯誤！")
              return done(err);
            }

            if (user) {
              console.log("資料庫有這筆臉書資料");

              detectExpired(user.facebook.token, function(res, err) {
                console.log(res)
                if (res) {
                  console.log('token 還沒過期');
                  //token還沒過期
                  return done(null, user, req.flash('fbloginsuccuss', 'fbloginsuccuss')); // user found, return that user
                } else {
                  //token過期
                  console.log("token已過期");
                  extendToken(token, function(res, err) {
                    console.log("更新token");
                    user.facebook.token = res;
                    user.save(function(err) {
                      if (err)
                        throw err;

                      return done(null, user, req.flash('fbloginsuccuss', 'fbloginsuccuss')); // user found, return that user
                    });
                  });
                }
              });

            } else {
              // if there is no user, create them
              console.log("資料庫沒有這筆臉書資料");

              console.log(token);
              console.log(refreshToken);
              console.log(profile);
              var newUser = new User();

              newUser.facebook.id = profile.id;
              // newUser.facebook.token = token;
              newUser.facebook.name = profile.displayName;
              newUser.facebook.email = profile.emails[0].value;
              newUser.randomEmail = profile.emails[0].value;
              newUser.apptoken = ' ';

              newUser.facebook.userGrantedString = stringifyPermissionsForDb;

              extendToken(token, function(res, err) {
                console.log("----------new Long-lived-token");
                console.log(res);
                newUser.facebook.token = res; //long-lived token

                newUser.save(function(err) {
                  if (err) {
                    console.log("存進資料庫失敗");
                    console.log(err);
                    throw err;
                  } else {
                    console.log("存進資料庫");
                    return done(null, newUser, req.flash('newFBuserFromLogin', 'newFBuserFromLogin'));
                  }


                });
              });


            }
          });

        } else {
          // user already exists and is logged in, we have to link accounts
          console.log("===== user already exists and is logged in, we have to link accounts =====");
          console.log("========= fb user profile （欲連結的臉書帳號） ============");
          console.log(profile);
          console.log("======================");

          console.log("========= local user (目前登入的) ============");
          console.log(req.user);
          console.log("======================");

          var user = req.user; // pull the user out of the session

          user.facebook.id = profile.id;
          user.facebook.token = token;
          user.facebook.name = profile.displayName;
          user.facebook.email = profile.emails[0].value;



          //從臉書id去撈db中的那筆用戶資料

          User.findOne({
            'facebook.id': profile.id
          }, function(err, userByFb) {
            if (err) {
              //未知錯誤
            } else if (userByFb === null) {
              //目前資料庫裡沒有這個臉書帳號
              user.save(function(err) {
                if (err) throw err;
                return done(null, user);
              });
            } else {
              //資料庫裡有這個臉書帳號
              console.log("資料庫裡有這個臉書帳號");

              if (userByFb.local.email) {
                //此連書帳號已經跟別的本地帳號連結
                console.log("此連書帳號已經跟別的本地帳號連結");
                return done(null, false, req.flash('checkAccount', user.facebook.email + '此連書帳號已經跟別的本地帳號連結'));
              } else {
                //此臉書帳號還沒有跟本地帳號連結
                console.log("此臉書帳號還沒有跟本地帳號連結");
                user.save(function(err) { //因為根本的帳號連結，資料庫會產生一筆新的記錄，所以要把舊的刪掉
                  if (err)
                    throw err;

                  User.remove({
                    '_id': userByFb._id
                  }, function(err, result) {
                    if (err) {
                      throw err
                    }

                    return done(null, user, req.flash('linkingSusses', 'linkingSusses'));
                  });

                });

              }
            }

          });



        }
      });

    }));

};


function extendToken(shortLiveToken, callback) {
  var propertiesObject = {
    "grant_type": 'fb_exchange_token',
    "client_id": configAuth.facebookAuth.clientID,
    "client_secret": configAuth.facebookAuth.clientSecret,
    "fb_exchange_token": shortLiveToken
  };
console.log(JSON.stringify(propertiesObject)+"****");

  request({
      url:"https://graph.facebook.com/oauth/access_token?client_id="+configAuth.facebookAuth.clientID+"&client_secret="+configAuth.facebookAuth.clientSecret+"&grant_type=fb_exchange_token&fb_exchange_token="+shortLiveToken
    //url: "https://graph.facebook.com/oauth/access_token",
    //qs: propertiesObject
  }, function(err, response, body) {
    if (err) {
      console.log(err);
      return callback(null, err);
    }
    var newToken = JSON.parse(body.toString());

   console.log(newToken.access_token+"*456*");

    return callback(newToken.access_token, null);
  });
}

function detectExpired(testToken, callback) {
  var propertiesObject = {
    "input_token": testToken,
    "access_token": configAuth.facebookAuth.clientID + '|' + configAuth.facebookAuth.clientSecret
  };

  request({
    url: "https://graph.facebook.com/v2.9/debug_token",
    qs: propertiesObject
  }, function(err, response, body) {
    if (err) {
      console.log(err);
      return callback(null, err);
    }
    var json_body = JSON.parse(body);
      console.log(json_body.data.is_valid);
    return callback(json_body.data.is_valid, null);
  });
}