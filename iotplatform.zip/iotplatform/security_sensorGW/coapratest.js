var crypto = require('crypto');
var CryptoJS = require("crypto-js");
var Session_Key="OFFuWVJPVytoM0JZS3BSTTVZSGhOZz09";///Session Key******OFFuWVJPVytoM0JZS3BSTTVZSGhOZz09
var bodyParser   = require('body-parser');
const coap  = require('coap') // or coap
  , server = coap.createServer({
    host: '192.168.0.108',////gateway自己的IP
  }), port = 5683
var ponte_ip="";

var Base64 = require('js-base64').Base64;
var gateway_IP=Base64.encodeURI('192.168.0.108');//gatewayip//********************
//想傳送的data
var discovery_data1={'UUID':"34343434",'TYPE':"1002,1001,4001"};
var discovery_data2={'UUID':"12121212",'TYPE':"4002,1001,1_1"};
var discovery_data={'a':discovery_data1,
                    'b':discovery_data2}
var body=JSON.stringify(discovery_data);

// Create servers
server.on('request', function(msg, res) {
  var path =msg.url;       //將收到的位置(path)拿出來比對
var ip2=JSON.stringify(msg.rsinfo);//讀取ponte IP
var ip = JSON.parse(ip2.toString());//轉成json格式讀出IP

  switch (path) {       //根據不同的path做不同的事情
    case '/'+gateway_IP+'/discovery_request':
      console.log("123")
      ponte_ip=ip.address;//ip.address為ponte IP
       res.end(body);//回送給ponte payload內容
        break;
    case '/'+gateway_IP+'/Actuator':
        var Actuator=""+msg.payload;
        console.log(Actuator+"*~*");//web端送過來192.168.1.143/oxoxoxoxoxoxoxo SG_IP/UUID
         //可在這裡加上function並結合Actuator去做控制
        break;

}
  res.end()
})

server.listen(5683, function() {
  console.log('Server is listening')
  var start=setInterval(sendAuthentication,5000);//3600000//5秒送一次憑證訊息
})


//發送憑證訊息
function sendAuthentication(){
var buf = crypto.randomBytes(16);
var plaintext=Base64.encodeURI(buf.toString('base64'));
var ciphertext1 = CryptoJS.AES.encrypt(plaintext, Session_Key);
var ciphertext=ciphertext1+"";
var topic=gateway_IP+"/Authentication";//*********
var req = coap.request({
  host:"127.0.0.1",/////ponte IP
  port:5683,
  method:'put',
  pathname:"/r/"+topic,
});

var payload={
'plaintext':plaintext,
'ciphertext':ciphertext
};

req.write(JSON.stringify(payload));
//req.write(time);
req.on('response', function(res) {
      res.pipe(process.stdout)
req.on('end', function() {
      res.pipe('end')
});

});
req.end()
console.log(JSON.stringify(payload));
}


///////sensor data//////////////////////////////////////////////////////////
 //將想傳送的sensor data切好再送出去
 /*
 var sensor_data={
  'uuid':"oxoxoxo/54",
  'data':32
  //'utcTime':utcTime
};
//已經知道ponte IP,才可以送東西
if(ponte_ip!==""){
put_sensor_data(sensor_data);//切好sensor data都要執行這個方法,送出sensor data
}

function put_sensor_data(sensor_data){
   var start=setInterval(put_sensor_data_to_ponte,5000,sensor_data,ponte_ip);
}
//向ponte送出sensors data
function put_sensor_data_to_ponte(payload,ip){
var sensor_data_topic=payload.uuid;// oxoxoxo/54
var req = coap.request({
  host:ip,//ponte_ip
  port:5683,
  method:'put',
  pathname:'/r/'+sensor_data_topic
});
console.log(payload.data);
req.write(JSON.stringify(payload));
req.on('response', function(res) {
      res.pipe(process.stdout)
req.on('end', function() {
      res.pipe('end')
});

});
req.end()
}*/

