var crypto = require('crypto');///////
var CryptoJS = require("crypto-js");////
var Session_Key="Ulh4Wnd3MGhna3Y2RmI4dnpScG1ldz09";//Session Key///Ulh4Wnd3MGhna3Y2RmI4dnpScG1ldz09
var server,
    ip   = "192.168.0.107",//gateway自己的IP//********************
    port = 3001,
    url = require('url'),
    path;
const http  = require('http');
var ponte_ip="";
var Base64 = require('js-base64').Base64;
var gateway_IP=Base64.encodeURI(ip);
 //想傳送的data
var discovery_data1={'UUID':"87878787",'TYPE':"4001,1_0,1001"};
var discovery_data2={'UUID':"74747474",'TYPE':"1002,1_1,4002"};
var discovery_data={'a':discovery_data1,
                    'b':discovery_data2}
var body=JSON.stringify(discovery_data);



server = http.createServer(function (req, res) {
      path = url.parse(req.url);
     var ponte_address='';
      var ip2 = req.connection.remoteAddress;//讀取ponte的IP
      for(var i=7;i<ip2.length;i++){
      ponte_address=ponte_address+ip2[i];
      }

    res.writeHead(200, {'Content-Type': 'text/plain'});

    switch (path.pathname) {
    case '/'+gateway_IP+'/discovery_request':
        //sendURL(ip);
        ponte_ip=ponte_address;
        res.end(body);//回送給ponte payload內容
        break;
    case '/'+gateway_IP+"/Actuator":
        var bodydata = '';
        req.on('data', function (data) {
            bodydata += data;
        });

        req.on('end', function () {
             console.log(bodydata);//{'data':192.168.1.140/oxoxoxoxoxox/36}
            var Actuator=bodydata;//web端送過來{'data':192.168.1.140/oxoxoxoxoxox/36}SG_IP/UUID
             //可在這裡加上function並結合Actuator去做控制
        });

        break;
    default:
        res.end('default page.\n');
        break;
    }
    res.end()
});
server.listen(port, function() {
console.log("Server running at http://" + ip + ":" + port);
var start=setInterval(sendAuthentication,5000);//3600000//5秒送一次憑證訊息
});

//發送憑證訊息
function sendAuthentication(){
var buf = crypto.randomBytes(16);
var plaintext=Base64.encodeURI(buf.toString('base64'));
var ciphertext1 = CryptoJS.AES.encrypt(plaintext, Session_Key);
var ciphertext=ciphertext1+"";
var topic=gateway_IP+"/Authentication";//*********
var options = {
  "host":"127.0.0.1",//ponte IP
  "port":3001,
  "path":"/resources/"+topic,
  "method":"put"
};

callback =function(response){
var str=''
response.on('data',function(chunk){
str += chunk
})
response.on('end',function(){
  //console.log(str)
})
}

var body=JSON.stringify({
'plaintext':plaintext,
'ciphertext':ciphertext
});
console.log(body);
http.request(options, callback).end(body);

}


///////sensor data//////////////////////////////////////////////////////////
//將想傳送的sensor data切好再送出去
/*
 var sensor_data={
  'uuid':"oxoxoxo/54",
  'data':32
  //'utcTime':utcTime
};
//已經知道ponte IP,才可以送東西
if(ponte_ip!==""){
put_sensor_data(sensor_data);//切好sensor data都要執行這個方法,送出sensor data
}

function put_sensor_data(sensor_data){
   var start=setInterval(put_sensor_data_to_ponte,5000,sensor_data,ponte_ip);
}
//向ponte送出sensors data
function put_sensor_data_to_ponte(payload,ip){

var sensor_data_topic=gateway_IP+'/'+payload.uuid;// oxoxoxo/54
//var utxTime=dateFormat(new Date(),"isoUtcDateTime");
var options = {
  "host":ip, //ponte_ip
  "port":3001,
  "path":"/resources/"+sensor_data_topic,// oxoxoxo/54
  "method":"put"
};

callback =function(response){
var str=''
response.on('data',function(chunk){
str += chunk
})
response.on('end',function(){
  //console.log(str)
})
}
console.log(payload.data);
var body=JSON.stringify(payload);
http.request(options, callback).end(body);
}*/
