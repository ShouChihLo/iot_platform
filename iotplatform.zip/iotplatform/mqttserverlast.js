//gateway端程式
var Base64 = require('js-base64').Base64;
var mqtt   = require('mqtt');
var gateway_ip=Base64.encodeURI('192.168.0.100');//gatewayip
var ponte_ip='192.168.0.100:1883';//ponte ip

//sevice discovery URL

var discovery_data1={'UUID':"pnpnpnpn",'TYPE':"1002,1001,2_0"};
var discovery_data2={'UUID':"lolololo",'TYPE':"1002,1_1,4001"};
var discovery_data={'a':discovery_data1,
                    'b':discovery_data2}

console.log(discovery_data);
var client = mqtt.connect('mqtt://'+ponte_ip);
var sevice_discovery_topic = gateway_ip+'/discovery_request';
var Actuator_topic = gateway_ip+'/Actuator';
client.on('connect', function () {
   client.subscribe(sevice_discovery_topic);//訂閱服務發現請求
   client.subscribe(Actuator_topic);//訂閱控制訊息
});

client.on('message', function (topic, message) {
  // message is Buffer
  console.log(topic);
  if(topic===Actuator_topic){
    console.log(message.toString());
  }else{
    var payloadJSON=JSON.parse(message.toString());
    console.log(payloadJSON.will_message);
    if(payloadJSON.will_message==="null"){//如果斷線後從開後會收到這個,這示只收到蓋掉的訊息,不做任何事情

    }else{//這邊是真的收到服務發現請求
 var str=message.toString();
  send_discovery_response(discovery_data,str);//呼叫送出服務資源方法
    }

  }

});

//送出服務資源
function send_discovery_response(payloads,payloadJSON){
var ip=gateway_ip;//gateway IP
var topic=ip+'/discovery_response';

var a=JSON.stringify(payloads);
var s={
"discovery_data":a,
"user_data":payloadJSON
}
console.log("**"+JSON.stringify(s)+"**");
var payload=s;
var client =mqtt.connect('mqtt://'+ponte_ip);//ponte ip
client.publish(topic,JSON.stringify(payload),{
  retain:true
})
client.end();
console.log(payloads);
}



/*
//put sensorsdata
function sendData(uuid,payloads){
var ip=gateway_ip;//gateway ip
var topic=ip+uuid;//sensordata topic
var payload=payloads;
var client =mqtt.connect('mqtt://'+ponte_ip);
client.publish(topic,JSON.stringify(payload),{
  retain:true
})
client.end();
}*/
